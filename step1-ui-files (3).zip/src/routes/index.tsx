import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  Banknote,
  CalendarDays,
  HandHeart,
  Hash,
  Mail,
  MessageCircle,
  Share2,
  User,
  Users,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Navbar } from "@/components/Navbar";
import { BottomNav } from "@/components/BottomNav";
import { NewsTicker } from "@/components/NewsTicker";
import { Gallery } from "@/components/Gallery";
import { Articles } from "@/components/Articles";
import { Reports } from "@/components/Reports";
import { DonationCalculator } from "@/components/DonationCalculator";
import { ImpactCorner } from "@/components/ImpactCorner";
import { CommunityWall } from "@/components/CommunityWall";
import { Volunteers } from "@/components/Volunteers";
import { MonthlyReminder } from "@/components/MonthlyReminder";
import { VisitorCounter } from "@/components/VisitorCounter";
import { Achievements } from "@/components/Achievements";
import { CountdownTimer } from "@/components/CountdownTimer";
import { GoalProgress } from "@/components/GoalProgress";
import { CampaignBanner } from "@/components/CampaignBanner";
import { PublicProjects } from "@/components/PublicProjects";
import heroImage from "@/assets/hero-wheat.jpg";
import logoAsset from "@/assets/sanabel-logo.png";

const TITLE = "سنابل الخير | جمعية تكافلية لدعم الأسر المتعففة";
const DESCRIPTION =
  "سنابل الخير مبادرة تكافلية لدعم الأسر المتعففة عبر مساهمات شهرية بسيطة وترشيحات مباشرة من أهل الحي. تعرّف على قصتنا وإنجازاتنا وطرق التبرع.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const PHONE = "+249115819197";
const WHATSAPP_GROUP =
  "https://chat.whatsapp.com/F9Kq2MU4T1G39OrbHY9jI0?s=cl&p=a&mlu=4&ilr=4";

// ===== التبويبات: كل تبويب يعرض أقسامه فقط (الشريط السفلي + روابط # داخل الصفحة) =====
export type Tab = "home" | "about" | "impact" | "donate" | "reports" | "contact";
const TAB_SECTIONS: Record<Tab, string[]> = {
  home: ["home", "goal"],
  about: ["about", "articles", "volunteers"],
  impact: ["achievements", "gallery", "impact", "projects"],
  donate: ["donate"],
  reports: ["reports"],
  contact: ["wall", "contact"],
};
const SECTION_TAB: Record<string, Tab> = Object.fromEntries(
  (Object.keys(TAB_SECTIONS) as Tab[]).flatMap((t) => TAB_SECTIONS[t].map((id) => [id, t])),
);

function useTab(): Tab {
  const [tab, setTab] = useState<Tab>("home");
  useEffect(() => {
    const sync = () => {
      const id = window.location.hash.slice(1);
      setTab(SECTION_TAB[id] ?? "home");
      requestAnimationFrame(() => {
        const el = id ? document.getElementById(id) : null;
        if (el && SECTION_TAB[id] !== id) el.scrollIntoView({ behavior: "smooth" });
        else window.scrollTo({ top: 0 });
      });
    };
    sync();
    window.addEventListener("hashchange", sync);
    return () => window.removeEventListener("hashchange", sync);
  }, []);
  return tab;
}

function Index() {
  const tab = useTab();
  useEffect(() => {
    const sections = Array.from(document.querySelectorAll("main section"));
    const targets = sections.filter((s) => s.id !== "home");
    targets.forEach((s) => s.classList.add("reveal"));
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.08, rootMargin: "0px 0px -40px 0px" },
    );
    targets.forEach((s) => observer.observe(s));
    return () => observer.disconnect();
  }, []);

  return (
    <div className="min-h-screen overflow-x-hidden bg-background pb-20">
      <Navbar />
      <NewsTicker />
      <main>
        {tab === "home" && (
          <>
            <Hero />
            <GoalProgress />
          </>
        )}
        {tab === "about" && (
          <>
            <About />
            <Articles />
            <Volunteers />
          </>
        )}
        {tab === "impact" && (
          <>
            <Achievements />
            <Gallery />
            <ImpactCorner />
            <PublicProjects />
          </>
        )}
        {tab === "donate" && <Donate />}
        {tab === "reports" && <Reports />}
        {tab === "contact" && (
          <>
            <CommunityWall />
            <Contact />
          </>
        )}
      </main>
      <Footer />
      <FloatingDonateButton />
      <BottomNav active={tab} />
      <MonthlyReminder />
    </div>
  );
}

function Hero() {
  const [shareLabel, setShareLabel] = useState("شارك الخير");

  const shareSite = async () => {
    const shareData = {
      title: "سنابل الخير",
      text: "ساهم معنا في سنابل الخير وكن سبباً في صنع أثرٍ يبقى.",
      url: window.location.href,
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
        return;
      }

      if (navigator.clipboard) {
        await navigator.clipboard.writeText(window.location.href);
        setShareLabel("تم نسخ الرابط");
        window.setTimeout(() => setShareLabel("شارك الخير"), 2200);
        return;
      }

      window.open(
        `https://wa.me/?text=${encodeURIComponent(`${shareData.text} ${shareData.url}`)}`,
        "_blank",
        "noopener,noreferrer",
      );
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return;
      window.open(
        `https://wa.me/?text=${encodeURIComponent(`${shareData.text} ${shareData.url}`)}`,
        "_blank",
        "noopener,noreferrer",
      );
    }
  };

  return (
    <>
      <CampaignBanner />
      <section id="home" className="relative flex min-h-[calc(100svh-7.5rem)] items-center overflow-hidden">
      <img
        src={heroImage}
        alt="سنابل قمح ذهبية في ضوء الصباح"
        width={1600}
        height={1000}
        className="absolute inset-0 size-full object-cover"
      />
      <div className="absolute inset-0 bg-hero-gradient" />
      <div className="animate-slow-float pointer-events-none absolute -top-24 right-[-6rem] size-80 rounded-full bg-accent/20 blur-[110px]" />

      <div className="relative mx-auto w-full max-w-7xl px-4 py-20 sm:px-6 sm:py-28">
        <div className="max-w-3xl text-primary-foreground">
          <span className="animate-rise inline-flex items-center gap-3 rounded-full border border-primary-foreground/25 bg-primary-deep/35 py-2 pe-5 ps-2 text-sm font-bold backdrop-blur-md">
            <img
              src={logoAsset}
              alt="شعار سنابل الخير"
              width={28}
              height={28}
              className="size-7 rounded-full bg-card object-contain"
            />
            عطاءٌ ينمو وأثرٌ يبقى
          </span>

          <div className="animate-rise mt-8 [animation-delay:0.05s]">
            <p className="font-quran text-lg leading-[2.2] text-primary-foreground/90 sm:text-xl">
              ﴿مَّثَلُ الَّذِينَ يُنفِقُونَ أَمْوَالَهُمْ فِي سَبِيلِ اللَّهِ كَمَثَلِ حَبَّةٍ
              أَنبَتَتْ سَبْعَ سَنَابِلَ فِي كُلِّ سُنبُلَةٍ مِّائَةُ حَبَّةٍ﴾
            </p>
          </div>

          <h1 className="animate-rise mt-7 text-center text-5xl font-black leading-[1.2] [animation-delay:0.15s] sm:text-7xl">
            سنابل الخير
            <span className="font-display mt-3 block text-4xl font-normal text-accent sm:text-6xl">
              رفقة خير وأثر
            </span>
          </h1>
          <p className="animate-rise mt-7 max-w-2xl text-base leading-loose text-primary-foreground/85 [animation-delay:0.25s] sm:text-xl">
            نمد معاً يد العون للأسر المتعففة، ونحوّل المساهمات الشهرية البسيطة إلى احتياجات
            أساسية تصل بستر وكرامة.
          </p>

          <div className="animate-rise mt-10 flex flex-wrap gap-4 [animation-delay:0.35s]">
            <Button asChild variant="gold" size="xl" className="min-w-48">
              <a href="#donate">
                <HandHeart className="size-5" />
                ساهم معنا
              </a>
            </Button>
            <Button asChild variant="heroOutline" size="xl" className="min-w-48">
              <a href="#achievements">شاهد أثر العطاء</a>
            </Button>
            <Button
              type="button"
              variant="heroOutline"
              size="xl"
              className="min-w-48"
              onClick={shareSite}
              aria-label="مشاركة موقع سنابل الخير"
            >
              <Share2 className="size-5" />
              {shareLabel}
            </Button>
          </div>

          <CountdownTimer />
        </div>
      </div>
    </section>
    </>
  );
}

const pillars = [
  {
    icon: HandHeart,
    title: "أثرٌ يبقى",
    text: "هدفنا أن نترك أثراً حقيقياً في حياة أسرة، لا مجرد مساعدة عابرة.",
  },
  {
    icon: Users,
    title: "الأقربون أولى بالمعروف",
    text: "تُرشَّح الأسر المستحقة مباشرة من أعضاء المجموعة، فهم أعلم بحال من حولهم، فيصل الدعم بستر وكرامة.",
  },
  {
    icon: Banknote,
    title: "تجارة رابحة",
    text: "الصدقة استثمار لا يخسر؛ حبة واحدة تُنبت سبع سنابل، وفي كل سنبلة مائة حبة.",
  },
];

function About() {
  return (
    <section id="about" className="py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid items-end gap-8 lg:grid-cols-[0.9fr_1.1fr]">
          <div>
            <span className="text-sm font-black text-accent">قصة سنابل الخير</span>
            <h2 className="mt-4 text-4xl font-black leading-tight sm:text-5xl">
              من فكرة بسيطة
              <br />
              <span className="font-display font-normal text-primary">إلى سنابل تنمو</span>
            </h2>
          </div>
          <p className="leading-loose text-muted-foreground">
            بدأت سنابل الخير — التي كانت تُعرف سابقاً بصندوق الخير — من رغبة صادقة في أن نترك
            أثراً في حياة من حولنا. آمنّا أن التكافل بين أفراد المجتمع هو أقصر طريق لسدّ حاجة
            الأسر المتعففة، وأن الدعم يصل لمستحقه في ستر وكرامة.
          </p>
        </div>

        <div className="mt-14 grid gap-px overflow-hidden rounded-md border border-border bg-border shadow-soft md:grid-cols-3">
          {pillars.map((p) => (
            <article key={p.title} className="group bg-card p-8 transition-colors hover:bg-primary-soft">
              <span className="flex size-12 items-center justify-center rounded-md bg-primary-soft text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                <p.icon className="size-6" />
              </span>
              <h3 className="mt-6 text-xl font-black">{p.title}</h3>
              <p className="mt-3 leading-loose text-muted-foreground">{p.text}</p>
            </article>
          ))}
        </div>

        <div className="mt-12 grid overflow-hidden rounded-md bg-primary-deep text-primary-foreground shadow-lift md:grid-cols-[1.2fr_0.8fr]">
          <div className="p-8 sm:p-10">
            <h3 className="text-2xl font-black">نظام المساهمة الشهرية</h3>
            <p className="mt-4 max-w-xl leading-loose text-primary-foreground/70">
              مساهمة شهرية متواضعة قدرها <strong className="text-accent">10,000</strong> من كل
              عضو، تجتمع لتتحول إلى سلال غذائية واحتياجات أساسية لأسرٍ تنتظر يد الخير.
            </p>
          </div>
          <div className="grid grid-cols-2 border-t border-primary-foreground/10 md:border-t-0 md:border-r">
            <div className="p-7">
              <Banknote className="size-6 text-accent" />
              <p className="mt-5 text-sm text-primary-foreground/60">قيمة المساهمة</p>
              <p className="mt-1 text-2xl font-black">10,000</p>
            </div>
            <div className="border-r border-primary-foreground/10 p-7">
              <CalendarDays className="size-6 text-accent" />
              <p className="mt-5 text-sm text-primary-foreground/60">موعد السداد</p>
              <p className="mt-1 text-2xl font-black">1 — 10</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

const bankDetails = [
  { icon: Banknote, label: "البنك", value: "بنك الخرطوم" },
  { icon: Hash, label: "رقم الحساب", value: "7996868" },
  { icon: User, label: "اسم الحساب", value: "إسراء النور إبراهيم" },
];

function Donate() {
  return (
    <section id="donate" className="py-24">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-sm font-black text-accent">طرق التبرع المباشر</span>
          <h2 className="mt-4 text-4xl font-black sm:text-5xl">تبرع الآن بكل سهولة</h2>
          <p className="mt-4 leading-loose text-muted-foreground">
            حوّل إلى الحساب الرسمي للجمعية، ثم أرسل إشعار التحويل عبر واتساب لتوثيق مساهمتك.
          </p>
        </div>

        <DonationCalculator />

        <div className="mt-12 grid gap-px overflow-hidden rounded-md border border-border bg-border shadow-soft sm:grid-cols-3">
          {bankDetails.map((d) => (
            <div key={d.label} className="bg-card p-8 text-center">
              <d.icon className="mx-auto size-7 text-accent" />
              <p className="mt-5 text-sm text-muted-foreground">{d.label}</p>
              <p className="mt-2 text-xl font-black tracking-wide text-primary-deep">{d.value}</p>
            </div>
          ))}
        </div>

        <div className="mt-8 text-center">
          <Button asChild variant="gold" size="xl">
            <a href={`https://wa.me/${PHONE.replace("+", "")}`} target="_blank" rel="noreferrer">
              <MessageCircle className="size-5" />
              أرسل إشعار التحويل عبر واتساب
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
}

function Contact() {
  return (
    <section id="contact" className="relative overflow-hidden bg-primary-deep py-24 text-primary-foreground">
      <div className="pointer-events-none absolute inset-0 pattern-grain text-primary-foreground/5" />
      <div className="pointer-events-none absolute -top-20 -left-20 size-72 rounded-full bg-accent/15 blur-[100px]" />
      <div className="relative mx-auto max-w-4xl px-4 text-center sm:px-6">
        <span className="inline-flex items-center gap-2 rounded-full border border-accent/40 bg-accent/15 px-4 py-1.5 text-sm font-bold text-accent">
          <Mail className="size-4" />
          نحن هنا لاستقبال رسالتك
        </span>
        <h2 className="mt-5 text-4xl font-black sm:text-5xl">تواصل معنا</h2>
        <p className="mx-auto mt-5 max-w-xl leading-loose text-primary-foreground/75">
          انضم إلى مجموعة الواتساب للمتابعة اللحظية، أو راسلنا عبر البريد للاستفسار وترشيح
          أسرة مستحقة.
        </p>

        <div className="mt-10 flex flex-wrap justify-center gap-4">
          <Button asChild variant="gold" size="xl" className="min-w-64">
            <a href="mailto:vsob99@gmail.com">
              <Mail className="size-5" />
              <span dir="ltr">vsob99@gmail.com</span>
            </a>
          </Button>
          <Button asChild variant="heroOutline" size="xl" className="min-w-64">
            <a href={WHATSAPP_GROUP} target="_blank" rel="noreferrer">
              <MessageCircle className="size-5" />
              انضم إلى مجموعة واتساب
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
}

function FloatingDonateButton() {
  return (
    <Button
      asChild
      variant="gold"
      className="fixed bottom-24 left-4 z-40 h-12 rounded-full px-5 text-sm shadow-lift sm:bottom-24 sm:left-6 sm:h-13 sm:px-6 sm:text-base"
    >
      <a href="#donate" aria-label="تبرع الآن">
        <HandHeart className="size-5" />
        تبرع الآن
      </a>
    </Button>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border bg-card py-12">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-6 px-4 text-center sm:px-6 md:flex-row md:text-right">
        <div className="flex items-center gap-3">
          <img
            src={logoAsset}
            alt="شعار سنابل الخير"
            width={44}
            height={44}
            className="size-11 rounded-md border border-primary/10 object-contain"
          />
          <div>
            <p className="font-black text-primary-deep">سنابل الخير</p>
            <p className="mt-1 text-sm text-muted-foreground">عطاء ينمو وأثر يبقى</p>
          </div>
        </div>
        <p className="text-sm text-muted-foreground">
          جميع الحقوق محفوظة لصالح جمعية سنابل الخير التكافلية
        </p>
        <VisitorCounter />
      </div>
    </footer>
  );
}
