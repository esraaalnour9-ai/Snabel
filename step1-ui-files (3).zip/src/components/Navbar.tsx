import { useState } from "react";
import { HandHeart, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import logoAsset from "@/assets/sanabel-logo.png";

const links = [
  { href: "#home", label: "الرئيسية" },
  { href: "#about", label: "قصة سنابل الخير" },
  { href: "#achievements", label: "مبادراتنا" },
  { href: "#impact", label: "أثرنا" },
  { href: "#projects", label: "مشاريعنا" },
  { href: "#reports", label: "التقارير" },
  { href: "#contact", label: "تواصل" },
];

export function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-border/70 bg-background/90 shadow-soft backdrop-blur-xl">
      <nav className="mx-auto flex h-20 max-w-7xl items-center justify-between gap-5 px-4 sm:px-6">
        <a href="#home" className="flex items-center gap-2.5">
          <img
            src={logoAsset}
            alt="شعار سنابل الخير"
            width={44}
            height={44}
            className="size-12 rounded-md border border-primary/10 bg-card object-contain shadow-soft"
          />
          <span className="text-xl font-black text-primary-deep">سنابل الخير</span>
        </a>

        <ul className="hidden items-center gap-8 lg:flex">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                 className="text-sm font-bold text-muted-foreground transition-colors hover:text-primary"
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-2">
          <Button asChild variant="gold" size="sm" className="hidden sm:inline-flex">
            <a href="#donate"><HandHeart className="size-4" />تبرع الآن</a>
          </Button>
          <Button
            type="button"
            variant="outline"
            size="icon"
            aria-label="القائمة"
            onClick={() => setOpen((v) => !v)}
            className="hidden"
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </Button>
        </div>
      </nav>

      {open && (
        <ul className="border-t border-border bg-background px-4 py-3 lg:hidden">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                onClick={() => setOpen(false)}
                className="block rounded-lg px-2 py-2.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-secondary hover:text-primary"
              >
                {l.label}
              </a>
            </li>
          ))}
          <li className="pt-2 sm:hidden">
            <Button asChild variant="gold" className="w-full">
              <a href="#donate" onClick={() => setOpen(false)}>
                تبرع الآن
              </a>
            </Button>
          </li>
        </ul>
      )}
    </header>
  );
}
