import { useState } from "react";
import { Camera, KeyRound, LogOut, MessageSquareHeart, SlidersHorizontal } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { roleLabel, type Account, type AppSettings } from "@/lib/mock-admin";
import { useAdminStore } from "./store";
import { Field, Panel, inputCls } from "./ui";

const STAGES = ["قبل الموعد (يوم 28)", "بداية الدفع (يوم 1)", "تذكير (يوم 5)", "آخر موعد (يوم 10)"];

export function Avatar({ user, size = 32 }: { user: Account; size?: number }) {
  return user.img
    ? <img src={user.img} alt="" style={{ width: size, height: size }} className="shrink-0 rounded-full object-cover" />
    : <span style={{ width: size, height: size, fontSize: size / 2.2 }} className="inline-flex shrink-0 items-center justify-center rounded-full bg-primary-soft font-black text-primary-deep">{user.name[0]}</span>;
}


const lines = (t: string) => t.split("\n").map((x) => x.trim()).filter(Boolean);

/** إعدادات خاصة بكل إدارة — تؤثر مباشرة على واجهتها */
function RoleSettings({ role }: { role: Account["role"] }) {
  const { settings, setSettings } = useAdminStore();
  const [d, setD] = useState<AppSettings>(settings);
  const set = <K extends keyof AppSettings>(k: K, v: AppSettings[K]) => setD((x) => ({ ...x, [k]: v }));
  const save = () => { setSettings(d); toast.success("تم حفظ إعدادات الإدارة"); };
  const area = `${inputCls} !h-auto py-3 leading-loose`;

  const body: Record<string, React.ReactNode> = {
    control: (
      <Field label="قيمة الاشتراك الشهري (ج.س) — تُستخدم في العضوية والتحصيل">
        <input type="number" min={1} className={inputCls} value={d.fee} onChange={(e) => set("fee", Number(e.target.value))} />
      </Field>
    ),
    collector: (
      <>
        <Field label="اسم المتحصل الافتراضي (يظهر في نموذج التحويل)"><input className={inputCls} value={d.collectorName} onChange={(e) => set("collectorName", e.target.value)} /></Field>
        <Field label="رسالة الواتساب الافتراضية للعضو">
          <textarea rows={4} className={area} value={d.collectorMsg} onChange={(e) => set("collectorMsg", e.target.value)} />
        </Field>
        <p className="text-xs text-muted-foreground">المتغيرات: {"{الاسم} {المبلغ} {التاريخ} {رقم العملية} {التفاصيل}"}</p>
      </>
    ),
    finance: (
      <>
        <Field label="اسم الأمين المالي الافتراضي"><input className={inputCls} value={d.treasurerName} onChange={(e) => set("treasurerName", e.target.value)} /></Field>
        <Field label="الجهات المستلمة عند الصرف (كل جهة في سطر)">
          <textarea rows={4} className={area} value={d.recipients.join("\n")} onChange={(e) => set("recipients", lines(e.target.value))} />
        </Field>
      </>
    ),
    projects: (
      <Field label="بنود المنصرفات الشائعة — تظهر كاقتراحات عند الكتابة (كل بند في سطر)">
        <textarea rows={5} className={area} value={d.items.join("\n")} onChange={(e) => set("items", lines(e.target.value))} />
      </Field>
    ),
    auditor: (
      <Field label="الفرق المقبول بين الإدارات (ج.س) — أي فرق أقل منه يُعدّ متطابقاً">
        <input type="number" min={0} className={inputCls} value={d.tolerance} onChange={(e) => set("tolerance", Number(e.target.value))} />
      </Field>
    ),
    media: (
      <Field label="خاتمة ثابتة تُضاف لكل منشور">
        <textarea rows={3} className={area} value={d.mediaFooter} onChange={(e) => set("mediaFooter", e.target.value)} />
      </Field>
    ),
    training: (
      <Field label="رابط استمارة التقديم الافتراضي">
        <input className={inputCls} dir="ltr" type="url" value={d.trainingLink} onChange={(e) => set("trainingLink", e.target.value)} />
      </Field>
    ),
  };
  if (!body[role]) return null;
  return (
    <Panel title={`إعدادات ${roleLabel(role)}`} icon={<SlidersHorizontal className="size-5" />}>
      <div className="space-y-4">{body[role]}<Button onClick={save}>حفظ الإعدادات</Button></div>
    </Panel>
  );
}

/** إعدادات كل إدارة: صورة، كلمة مرور، وللأمين: رسائل التذكير التحفيزية */
export function Settings({ user, patch, messages, setMessages, onLogout }: {
  user: Account; patch: (p: Partial<Account>) => void;
  messages: string[]; setMessages: (m: string[]) => void; onLogout: () => void;
}) {
  const [pw, setPw] = useState("");
  const [draft, setDraft] = useState(messages);

  const pickImage = (file?: File) => {
    if (!file) return;
    const r = new FileReader();
    r.onload = () => { patch({ img: String(r.result) }); toast.success("تم تحديث الصورة"); };
    r.readAsDataURL(file);
  };

  return (
    <div className="space-y-6">
      <Panel title="الصورة الشخصية" icon={<Camera className="size-5" />}>
        <div className="flex flex-wrap items-center gap-4">
          <Avatar user={user} size={72} />
          <div className="min-w-52 flex-1">
            <p className="font-black">{user.name}</p>
            <p className="mb-2 text-xs text-muted-foreground">{roleLabel(user.role)} · <span dir="ltr">{user.username}</span></p>
            <input type="file" accept="image/*" onChange={(e) => pickImage(e.target.files?.[0])}
              className="block w-full text-sm file:me-3 file:rounded-md file:border-0 file:bg-primary-soft file:px-3 file:py-2 file:font-bold file:text-primary-deep" />
          </div>
        </div>
      </Panel>

      <Panel title="تغيير كلمة المرور" icon={<KeyRound className="size-5" />}>
        <form className="flex flex-wrap items-end gap-3" onSubmit={(e) => {
          e.preventDefault(); patch({ password: pw }); setPw(""); toast.success("تم تغيير كلمة المرور");
        }}>
          <Field label="كلمة المرور الجديدة" className="min-w-52 flex-1">
            <input className={inputCls} dir="ltr" type="password" required minLength={4} value={pw} onChange={(e) => setPw(e.target.value)} />
          </Field>
          <Button type="submit">حفظ</Button>
        </form>
      </Panel>

      <RoleSettings role={user.role} />

      {user.role === "membership" && (
        <Panel title="رسائل التذكير التحفيزية" icon={<MessageSquareHeart className="size-5" />}>
          <p className="mb-4 text-xs leading-relaxed text-muted-foreground">
            اكتب نص الرسالة لكل مرحلة. المتغيرات المتاحة: <b>{"{الاسم}"}</b> و<b>{"{المبلغ}"}</b>.
          </p>
          <div className="space-y-4">
            {STAGES.map((s, i) => (
              <Field key={s} label={s}>
                <textarea rows={3} className={`${inputCls} !h-auto py-3 leading-loose`} value={draft[i] ?? ""}
                  onChange={(e) => setDraft((d) => d.map((x, j) => (j === i ? e.target.value : x)))} />
              </Field>
            ))}
            <Button onClick={() => { setMessages(draft); toast.success("تم حفظ رسائل التذكير"); }}>حفظ الرسائل</Button>
          </div>
        </Panel>
      )}

      <Panel title="الخروج">
        <div className="flex flex-wrap gap-2">
          <Button asChild variant="outline"><a href="/">العودة إلى الموقع</a></Button>
          <Button onClick={onLogout}><LogOut />تسجيل خروج</Button>
        </div>
      </Panel>
    </div>
  );
}
