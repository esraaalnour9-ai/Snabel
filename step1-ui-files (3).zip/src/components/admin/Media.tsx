import { useState } from "react";
import { Newspaper } from "lucide-react";
import { Button } from "@/components/ui/button";
import { posts as seed } from "@/lib/mock-admin";
import { Field, FileField, Panel, Table, inputCls, mockSubmit } from "./ui";
import { useAdminStore } from "./store";

const kinds = { none: "مقال فقط", image: "مع صورة", video: "مع فيديو" } as const;

export function Media({ section }: { section: string }) {
  const { settings } = useAdminStore();
  const [posts, setPosts] = useState(seed);
  const [kind, setKind] = useState<keyof typeof kinds>("none");
  return (
    <div className="space-y-6">
      {section === "new" && (
      <>
      <Panel title="نشر إنجاز / مقال" icon={<Newspaper className="size-5" />}>
        <form className="grid gap-4 sm:grid-cols-2" onSubmit={(e) => {
          mockSubmit("تم إرسال المنشور للنشر")(e);
          const d = new FormData(e.currentTarget as HTMLFormElement);
          setPosts((p) => [{ id: Date.now(), title: String(d.get("t")), body: String(d.get("b")), date: String(d.get("d")), media: kind }, ...p]);
          (e.currentTarget as HTMLFormElement).reset();
        }}>
          <Field label="العنوان"><input name="t" required className={inputCls} /></Field>
          <Field label="التاريخ"><input name="d" type="date" required className={inputCls} /></Field>
          <Field label="التفاصيل" className="sm:col-span-2"><textarea name="b" required rows={5} className={`${inputCls} !h-auto py-3`} /></Field>
          {settings.mediaFooter && <p className="rounded-md bg-primary-soft/60 p-3 text-xs leading-relaxed text-primary-deep sm:col-span-2">تُضاف تلقائياً في ختام كل منشور: {settings.mediaFooter}</p>}
          <Field label="نوع المرفق">
            <select className={inputCls} value={kind} onChange={(e) => setKind(e.target.value as keyof typeof kinds)}>
              {Object.entries(kinds).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
          </Field>
          {kind === "image" && <FileField label="الصورة" accept="image/*" />}
          {kind === "video" && <FileField label="الفيديو" accept="video/*" />}
          <div className="sm:col-span-2"><Button type="submit">نشر</Button></div>
        </form>
      </Panel>
      </>
      )}
      {section === "old" && (
      <>
      <Panel title="المنشورات السابقة">
        <Table head={["العنوان", "التاريخ", "المرفق", "المحتوى"]}>
          {posts.map((p) => (
            <tr key={p.id}><td className="font-bold">{p.title}</td><td>{p.date}</td><td>{kinds[p.media]}</td><td className="text-muted-foreground">{p.body}</td></tr>
          ))}
        </Table>
      </Panel>
      </>
      )}
    </div>
  );
}
