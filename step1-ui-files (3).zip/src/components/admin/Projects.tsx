import { useState } from "react";
import { CalendarClock, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { projects as seed, plans as seedPlans, total, fmt, type Project } from "@/lib/mock-admin";
import { Field, Panel, PrintBtn, Table, inputCls, mockSubmit } from "./ui";
import { useAdminStore } from "./store";

export function Projects({ section }: { section: string }) {
  const { settings } = useAdminStore();
  const [list, setList] = useState<Project[]>(seed);
  const [sel, setSel] = useState(seed[0].id);
  const [plans, setPlans] = useState(seedPlans);
  const p = list.find((x) => x.id === sel) ?? list[0];
  const patch = (fn: (p: Project) => Project) => setList((l) => l.map((x) => (x.id === p.id ? fn(x) : x)));

  return (
    <div className="space-y-6">
      {section === "proj" && (
      <>
      <Panel title="المشاريع والأنشطة" action={
        <form className="flex flex-wrap gap-2" onSubmit={(e) => {
          mockSubmit("تم إنشاء المشروع")(e);
          const d = new FormData(e.currentTarget as HTMLFormElement);
          const id = Date.now();
          setList((l) => [...l, { id, name: String(d.get("n")), date: String(d.get("d")), status: "active", expenses: [] }]);
          setSel(id);
        }}>
          <input name="n" required placeholder="اسم المشروع (التكية، إفطار...)" className={`${inputCls} !h-9 !w-52`} />
          <input name="d" required type="date" className={`${inputCls} !h-9 !w-40`} />
          <Button size="sm" type="submit"><Plus />مشروع جديد</Button>
        </form>
      }>
        <div className="flex flex-wrap gap-2">
          {list.map((x) => (
            <button key={x.id} type="button" onClick={() => setSel(x.id)}
              className={`rounded-md border px-3 py-2 text-sm font-bold transition ${x.id === p.id ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-primary-deep hover:border-primary"}`}>
              {x.name} <span className="text-xs opacity-70">· {x.date}</span>
            </button>
          ))}
        </div>
      </Panel>

      <Panel title={`منصرفات: ${p.name}`} action={<PrintBtn label="تصدير تقرير المشروع PDF" />}>
        <form className="mb-5 grid gap-3 sm:grid-cols-4" onSubmit={(e) => {
          mockSubmit("تمت إضافة المنصرف")(e);
          const d = new FormData(e.currentTarget as HTMLFormElement);
          patch((x) => ({ ...x, expenses: [...x.expenses, { id: Date.now(), item: String(d.get("i")), qty: Number(d.get("q")), unit: Number(d.get("u")) }] }));
          (e.currentTarget as HTMLFormElement).reset();
        }}>
          <Field label="اسم المنصرف"><input name="i" required list="expense-items" className={inputCls} /><datalist id="expense-items">{settings.items.map((i) => <option key={i} value={i} />)}</datalist></Field>
          <Field label="الكمية"><input name="q" type="number" min="1" step="any" required className={inputCls} /></Field>
          <Field label="سعر الوحدة"><input name="u" type="number" min="0" step="any" required className={inputCls} /></Field>
          <div className="flex items-end"><Button type="submit" className="w-full"><Plus />إضافة</Button></div>
        </form>
        <Table head={["المنصرف", "الكمية", "سعر الوحدة", "الإجمالي", ""]} empty={p.expenses.length === 0}>
          {p.expenses.map((x) => (
            <tr key={x.id}>
              <td className="font-bold">{x.item}</td><td>{x.qty}</td><td>{fmt(x.unit)}</td><td className="font-bold text-primary-deep">{fmt(x.qty * x.unit)}</td>
              <td><button type="button" aria-label="حذف" onClick={() => patch((y) => ({ ...y, expenses: y.expenses.filter((e) => e.id !== x.id) }))} className="text-destructive"><Trash2 className="size-4" /></button></td>
            </tr>
          ))}
        </Table>
        <p className="mt-4 rounded-md bg-primary-soft p-3 text-center text-lg font-black text-primary-deep">الإجمالي: {fmt(total(p.expenses))} ج.س</p>
      </Panel>

      </>
      )}
      {section === "plans" && (
      <>
      <Panel title="الخطط المستقبلية (تظهر للعامة)" icon={<CalendarClock className="size-5" />}>
        <form className="grid gap-3 sm:grid-cols-4" onSubmit={(e) => {
          mockSubmit("تمت إضافة الخطة")(e);
          const d = new FormData(e.currentTarget as HTMLFormElement);
          setPlans((l) => [...l, { id: Date.now(), title: String(d.get("t")), desc: String(d.get("s")), target: Number(d.get("m")), kind: "plan" }]);
          (e.currentTarget as HTMLFormElement).reset();
        }}>
          <Field label="عنوان الخطة"><input name="t" required className={inputCls} placeholder="تكية للطلاب" /></Field>
          <Field label="وصف مختصر" className="sm:col-span-2"><input name="s" required className={inputCls} /></Field>
          <Field label="المبلغ المطلوب"><input name="m" type="number" min="0" required className={inputCls} /></Field>
          <div className="sm:col-span-4"><Button type="submit">إضافة خطة</Button></div>
        </form>
        <div className="mt-5">
          <Table head={["الخطة", "الوصف", "المطلوب", "الحالة"]}>
            {plans.map((x) => (
              <tr key={x.id}><td className="font-bold">{x.title}</td><td className="text-muted-foreground">{x.desc}</td><td>{fmt(x.target)}</td><td>{x.kind === "plan" ? "قادم" : "قيد التنفيذ"}</td></tr>
            ))}
          </Table>
        </div>
      </Panel>
      </>
      )}
    </div>
  );
}
