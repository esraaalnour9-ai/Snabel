import { useState } from "react";
import { BellRing, MessageCircle, Pencil, UserPlus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { members as seed, paidThisMonth, fmt, type Member } from "@/lib/mock-admin";
import { useAdminStore } from "./store";
import { Field, Panel, Pill, Stat, Table, inputCls, mockSubmit } from "./ui";

const empty = { name: "", phone: "", whatsapp: "", joined: "", notes: "" };
const stages = ["قبل الموعد (يوم 28)", "بداية الدفع (يوم 1)", "تذكير (يوم 5)", "آخر موعد (يوم 10)"];

export function Membership({ section, messages }: { section: string; messages: string[] }) {
  const { settings } = useAdminStore();
  const [list, setList] = useState<Member[]>(seed);
  const [f, setF] = useState(empty);
  const [editing, setEditing] = useState<number | null>(null);
  const [stage, setStage] = useState(stages[2]);
  const unpaid = list.filter((m) => !paidThisMonth.has(m.id));

  const save = (e: React.FormEvent) => {
    mockSubmit(editing ? "تم تعديل العضو" : "تمت إضافة العضو")(e);
    if (editing) setList((l) => l.map((m) => (m.id === editing ? { ...m, ...f } : m)));
    else setList((l) => [...l, { id: Date.now(), ...f }]);
    setF(empty); setEditing(null);
  };

  return (
    <div className="space-y-6">
      {section === "list" && (
      <>
      <div className="grid grid-cols-3 gap-3">
        <Stat label="إجمالي الأعضاء" value={list.length} />
        <Stat label="سدّدوا هذا الشهر" value={list.length - unpaid.length} />
        <Stat label="لم يسدّدوا" value={unpaid.length} tone="danger" />
      </div>

      <Panel title={editing ? "تعديل بيانات عضو" : "إضافة عضو"} icon={<UserPlus className="size-5" />}>
        <form onSubmit={save} className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <Field label="الاسم"><input className={inputCls} required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
          <Field label="رقم الهاتف"><input className={inputCls} dir="ltr" required value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} /></Field>
          <Field label="رقم الواتساب"><input className={inputCls} dir="ltr" value={f.whatsapp} onChange={(e) => setF({ ...f, whatsapp: e.target.value })} /></Field>
          <Field label="تاريخ الانضمام"><input className={inputCls} type="date" required value={f.joined} onChange={(e) => setF({ ...f, joined: e.target.value })} /></Field>
          <Field label="بيانات خاصة بالعضوية" className="sm:col-span-2"><input className={inputCls} value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} /></Field>
          <div className="flex gap-2 sm:col-span-2 lg:col-span-3">
            <Button type="submit">{editing ? "حفظ التعديل" : "إضافة"}</Button>
            {editing && <Button type="button" variant="outline" onClick={() => { setEditing(null); setF(empty); }}>إلغاء</Button>}
          </div>
        </form>
      </Panel>

      <Panel title="قائمة الأعضاء">
        <Table head={["الاسم", "الهاتف", "واتساب", "الانضمام", "ملاحظات", ""]}>
          {list.map((m) => (
            <tr key={m.id}>
              <td className="font-bold">{m.name}</td>
              <td dir="ltr" className="text-right">{m.phone}</td>
              <td dir="ltr" className="text-right">{m.whatsapp}</td>
              <td>{m.joined}</td>
              <td className="text-muted-foreground">{m.notes || "—"}</td>
              <td><Button size="sm" variant="outline" onClick={() => { setEditing(m.id); setF({ name: m.name, phone: m.phone, whatsapp: m.whatsapp, joined: m.joined, notes: m.notes }); window.scrollTo({ top: 0, behavior: "smooth" }); }}><Pencil />تعديل</Button></td>
            </tr>
          ))}
        </Table>
      </Panel>

      </>
      )}
      {section === "pay" && (
      <>
      <Panel title={`متابعة السداد — الاشتراك ${fmt(settings.fee)} ج.س`} icon={<BellRing className="size-5" />}
        action={
          <div className="flex flex-wrap items-center gap-2">
            <select className={`${inputCls} !h-9 !w-auto`} value={stage} onChange={(e) => setStage(e.target.value)}>
              {stages.map((s) => <option key={s}>{s}</option>)}
            </select>
            <Button size="sm" variant="gold" onClick={() => toast.success(`تجريبي: سيتم إرسال تذكير «${stage}» إلى ${unpaid.length} أعضاء`)}>
              <MessageCircle />إرسال التذكير لغير المسدّدين
            </Button>
          </div>
        }>
        <div className="mb-4 rounded-md border border-accent/30 bg-accent-soft p-4">
          <p className="mb-1 text-xs font-black text-accent">نص الرسالة الحالي لمرحلة «{stage}» (يُعدَّل من الإعدادات)</p>
          <p className="text-sm leading-loose">{(messages[stages.indexOf(stage)] ?? "").replace("{الاسم}", "(اسم العضو)").replace("{المبلغ}", `${fmt(settings.fee)} ج.س`)}</p>
        </div>
        <Table head={["العضو", "الحالة", "رسالة مفردة"]}>
          {list.map((m) => {
            const ok = paidThisMonth.has(m.id);
            return (
              <tr key={m.id}>
                <td className="font-bold">{m.name}</td>
                <td><Pill ok={ok} yes="سدّد" no="لم يسدّد" /></td>
                <td>{!ok && <Button size="sm" variant="outline" onClick={() => toast.info(`تجريبي: رسالة إلى ${m.name}`)}><MessageCircle />تذكير</Button>}</td>
              </tr>
            );
          })}
        </Table>
      </Panel>
      </>
      )}
    </div>
  );
}
