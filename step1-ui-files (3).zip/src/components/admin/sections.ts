import {
  Archive, ClipboardList, Landmark, FileText, GraduationCap, Handshake, Hammer, CalendarClock, Newspaper,
  Receipt, Scale, Send, ShieldCheck, TrendingUp, Users, ArrowDownToLine, ArrowUpFromLine, CheckCircle2,
  type LucideIcon,
} from "lucide-react";
import type { Role } from "@/lib/mock-admin";

export type Sec = { id: string; label: string; icon: LucideIcon };

/** أقسام كل إدارة — تظهر كتبويبات في الشريط السفلي. قسم «rep» هو التقارير في كل إدارة. */
export const SECTIONS: Record<Role, Sec[]> = {
  control: [{ id: "acc", label: "الحسابات", icon: ShieldCheck }, { id: "rep", label: "تقارير", icon: FileText }],
  membership: [
    { id: "list", label: "الأعضاء", icon: Users }, { id: "pay", label: "السداد", icon: CheckCircle2 }, { id: "rep", label: "تقارير", icon: FileText },
  ],
  collector: [
    { id: "notice", label: "الإشعارات", icon: Receipt }, { id: "members", label: "الأعضاء", icon: Users }, { id: "send", label: "التحويل", icon: Send },
    { id: "part", label: "الشراكات", icon: Handshake }, { id: "rep", label: "تقارير", icon: FileText },
  ],
  finance: [
    { id: "sum", label: "الملخص", icon: TrendingUp }, { id: "vaults", label: "الخزن", icon: Landmark }, { id: "recv", label: "الاستلام", icon: ArrowDownToLine }, { id: "out", label: "الصرف", icon: ArrowUpFromLine },
    { id: "part", label: "الدعمات", icon: Handshake }, { id: "rep", label: "تقارير", icon: FileText },
  ],
  projects: [
    { id: "proj", label: "المشاريع", icon: Hammer }, { id: "plans", label: "الخطط", icon: CalendarClock }, { id: "rep", label: "تقارير", icon: FileText },
  ],
  auditor: [
    { id: "match", label: "المطابقة", icon: Scale }, { id: "sum", label: "الملخصات", icon: ClipboardList }, { id: "rep", label: "تقارير", icon: FileText },
  ],
  media: [
    { id: "new", label: "نشر", icon: Newspaper }, { id: "old", label: "المنشورات", icon: Archive }, { id: "rep", label: "تقارير", icon: FileText },
  ],
  training: [
    { id: "new", label: "إضافة فرصة", icon: GraduationCap }, { id: "list", label: "الفرص", icon: ClipboardList }, { id: "rep", label: "تقارير", icon: FileText },
  ],
};
