import { useState } from "react";
import { BarChart3 } from "lucide-react";
import { reportData, fmt, type Role } from "@/lib/mock-admin";
import { Field, Panel, PrintBtn, Stat, Table, inputCls } from "./ui";
import { Button } from "@/components/ui/button";

const MONTHS = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
const label = (ym: string) => `${MONTHS[Number(ym.slice(5)) - 1]} ${ym.slice(0, 4)}`;

/** تقرير بفترة زمنية (من شهر إلى شهر) — موجود في كل إدارة */
export function Report({ role }: { role: Role }) {
  const d = reportData[role];
  const [from, setFrom] = useState("2026-09");
  const [to, setTo] = useState("2026-11");
  const [range, setRange] = useState<{ from: string; to: string } | null>(null);

  const run = () => {
    if (!from || !to) return;
    setRange(from <= to ? { from, to } : { from: to, to: from }); // تصحيح تلقائي إذا انعكس الترتيب
  };
  const rows = range ? d.rows.filter((r) => String(r[0]).slice(0, 7) >= range.from && String(r[0]).slice(0, 7) <= range.to) : [];

  return (
    <div className="space-y-6">
      <Panel title={`${d.title} حسب الفترة`} icon={<BarChart3 className="size-5" />}>
        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="من شهر"><input type="month" className={inputCls} value={from} onChange={(e) => setFrom(e.target.value)} /></Field>
          <Field label="إلى شهر"><input type="month" className={inputCls} value={to} onChange={(e) => setTo(e.target.value)} /></Field>
          <div className="flex items-end"><Button onClick={run}>عرض التقرير</Button></div>
        </div>
      </Panel>

      {range && (
        <Panel title={`${d.title}: من ${label(range.from)} إلى ${label(range.to)}`} action={<PrintBtn />}>
          <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
            {d.summary(rows).map((s) => <Stat key={s.label} label={s.label} value={s.value} tone={s.tone} />)}
          </div>
          <Table head={d.cols} empty={rows.length === 0}>
            {rows.map((r, i) => (
              <tr key={i}>{r.map((c, j) => <td key={j}>{typeof c === "number" ? fmt(c) : c}</td>)}</tr>
            ))}
          </Table>
        </Panel>
      )}
    </div>
  );
}
