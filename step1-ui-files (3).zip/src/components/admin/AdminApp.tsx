import { useState } from "react";
import { Settings as SettingsIcon } from "lucide-react";
import { DEFAULT_MESSAGES, ROLES, initialAccounts, roleLabel, type Account, type Role } from "@/lib/mock-admin";
import { Login } from "./Login";
import { ControlPanel } from "./ControlPanel";
import { Membership } from "./Membership";
import { Collector } from "./Collector";
import { Finance } from "./Finance";
import { Projects } from "./Projects";
import { Auditor } from "./Auditor";
import { Media } from "./Media";
import { Training } from "./Training";
import { Report } from "./Report";
import { Avatar, Settings } from "./Settings";
import { SECTIONS } from "./sections";
import { AdminStoreProvider } from "./store";

type Tab = { id: string; label: string; icon: React.ComponentType<{ className?: string }> };

export function AdminApp() {
  return (
    <AdminStoreProvider>
      <AdminShell />
    </AdminStoreProvider>
  );
}

function AdminShell() {
  const [accounts, setAccounts] = useState<Account[]>(initialAccounts);
  const [userId, setUserId] = useState<number | null>(null);
  const [dept, setDept] = useState<string>("control"); // للكنترول: الإدارة المعروضة، أو "settings"
  const [sec, setSec] = useState<string>(""); // القسم داخل الإدارة
  const [messages, setMessages] = useState<string[]>(DEFAULT_MESSAGES);

  const user = accounts.find((a) => a.id === userId) ?? null;
  if (!user) return <Login accounts={accounts} onEnter={(a) => { setUserId(a.id); setDept(a.role); setSec(SECTIONS[a.role][0].id); }} />;

  const isControl = user.role === "control";
  const patch = (p: Partial<Account>) => setAccounts((x) => x.map((a) => (a.id === user.id ? { ...a, ...p } : a)));
  const logout = () => setUserId(null);

  // الشريط السفلي: للكنترول كل الإدارات، ولغيره أقسام إدارته فقط
  const settingsTab: Tab = { id: "settings", label: "الإعدادات", icon: SettingsIcon };
  const tabs: Tab[] = isControl
    ? [...ROLES.map((r) => ({ id: r.id, label: r.id === "control" ? "الحسابات" : r.label, icon: r.icon })), settingsTab]
    : [...SECTIONS[user.role], settingsTab];
  const active = isControl ? dept : sec;
  const onTab = (id: string) => {
    if (isControl) { setDept(id); setSec(id === "settings" ? "" : SECTIONS[id as Role][0].id); }
    else setSec(id);
    window.scrollTo({ top: 0 });
  };

  const showRole: Role | null = isControl ? (dept === "settings" ? null : (dept as Role)) : (sec === "settings" ? null : user.role);
  const curSec = showRole ? (SECTIONS[showRole].some((s) => s.id === sec) ? sec : SECTIONS[showRole][0].id) : "";

  const renderRole = (r: Role, s: string) => {
    if (s === "rep") return <Report role={r} />;
    switch (r) {
      case "control": return <ControlPanel accounts={accounts} setAccounts={setAccounts} />;
      case "membership": return <Membership section={s} messages={messages} />;
      case "collector": return <Collector section={s} />;
      case "finance": return <Finance section={s} />;
      case "projects": return <Projects section={s} />;
      case "auditor": return <Auditor section={s} />;
      case "media": return <Media section={s} />;
      case "training": return <Training section={s} />;
    }
  };

  return (
    <div className="min-h-screen bg-secondary/40">
      <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-2.5">
          <p className="text-base font-black text-primary-deep">سنابل الخير · الإدارة</p>
          <p className="flex items-center gap-2 text-xs text-muted-foreground">
            <Avatar user={user} size={28} />{user.name} — {roleLabel(user.role)}
          </p>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 pb-28 pt-5">
        {isControl && showRole && (
          <div className="mb-4 flex gap-2 overflow-x-auto">
            {SECTIONS[showRole].map((s) => (
              <button key={s.id} type="button" onClick={() => setSec(s.id)}
                className={`shrink-0 rounded-full border px-3 py-1.5 text-xs font-bold transition ${curSec === s.id ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-primary-deep"}`}>
                {s.label}
              </button>
            ))}
          </div>
        )}
        {showRole
          ? renderRole(showRole, curSec)
          : <Settings user={user} patch={patch} messages={messages} setMessages={setMessages} onLogout={logout} />}
      </main>

      <nav aria-label="التنقل" className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/95 shadow-lift backdrop-blur"
        style={{ paddingBottom: "env(safe-area-inset-bottom, 0px)" }}>
        <div className="mx-auto flex max-w-6xl gap-1 overflow-x-auto px-2 py-1.5">
          {tabs.map((t) => (
            <button key={t.id} type="button" onClick={() => onTab(t.id)} aria-current={active === t.id ? "page" : undefined}
              className={`flex min-w-[68px] flex-1 shrink-0 flex-col items-center gap-0.5 rounded-md px-2 py-1.5 text-[11px] font-bold transition ${active === t.id ? "bg-primary-soft text-primary-deep" : "text-muted-foreground hover:text-primary"}`}>
              <t.icon className="size-5" />{t.label}
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}
