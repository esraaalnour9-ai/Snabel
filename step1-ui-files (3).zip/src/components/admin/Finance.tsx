import { useState } from "react";
import { ArrowDownToLine, ArrowUpFromLine, CheckCircle2, Landmark, Users } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { members, paidThisMonth, computeTreasuries, TREASURIES, fmt, type Treasury } from "@/lib/mock-admin";
import { useAdminStore } from "./store";
import { Field, FileField, ImgThumb, Panel, PrintBtn, Pill, Stat, Table, inputCls } from "./ui";
import { PartnershipPanel } from "./Collector";

const label = (t: Treasury) => TREASURIES.find((x) => x.id === t)!.label;
const today = () => new Date().toISOString().slice(0, 10);

export function Finance({ section }: { section: string }) {
  const { payments, setPayments, transfers: trs, setTransfers: setTrs, partnerships, setPartnerships, outflows: outs, setOutflows: setOuts, settings } = useAdminStore();
  const [treasury, setTreasury] = useState<Treasury>("subs");
  const [err, setErr] = useState("");

  const vaults = computeTreasuries(payments, partnerships, outs);
  const balanceOf = (t: Treasury) => vaults.find((v) => v.id === t)!.balance;
  const total = vaults.reduce((s, v) => s + v.balance, 0);

  // حركات كل خزنة (وارد من الحركات المؤكَّدة + صرف)
  const nameOf = (id: number, payer?: string) => (id ? members.find((m) => m.id === id)?.name : payer) ?? "—";
  const movements = (t: Treasury) => {
    const m: { date: string; what: string; inn: number; out: number }[] = [];
    if (t !== "ext") payments.filter((p) => p.status === "confirmed").forEach((p) => {
      const v = t === "subs" ? p.sub : p.con;
      if (v > 0) m.push({ date: p.date, what: `${nameOf(p.memberId, p.payer)} — ${t === "subs" ? (p.months > 1 ? `اشتراك مقدَّم (${p.months} أشهر)` : "اشتراك شهري") : `مساهمة${p.desc ? ` (${p.desc})` : ""}`}`, inn: v, out: 0 });
    });
    if (t === "ext") partnerships.filter((x) => x.status === "confirmed").forEach((x) => m.push({ date: x.date, what: `${x.party} — ${x.type}`, inn: x.amount, out: 0 }));
    outs.filter((o) => o.treasury === t).forEach((o) => m.push({ date: o.date, what: `صرف إلى ${o.recipient} (${o.ref})`, inn: 0, out: o.amount }));
    return m.sort((a, b) => a.date.localeCompare(b.date));
  };

  // تقسيم التحويل على الخزن الثلاث
  const split = (t: { paymentIds: number[]; partnerIds: number[] }) => ({
    subs: payments.filter((p) => t.paymentIds.includes(p.id)).reduce((s, p) => s + p.sub, 0),
    cons: payments.filter((p) => t.paymentIds.includes(p.id)).reduce((s, p) => s + p.con, 0),
    ext: partnerships.filter((x) => t.partnerIds.includes(x.id)).reduce((s, x) => s + x.amount, 0),
  });

  const confirm = (t: (typeof trs)[number]) => {
    const sp = split(t);
    setTrs((x) => x.map((y) => (y.id === t.id ? { ...y, confirmed: true } : y)));
    setPayments((x) => x.map((y) => (t.paymentIds.includes(y.id) ? { ...y, status: "confirmed" } : y)));
    setPartnerships((x) => x.map((y) => (t.partnerIds.includes(y.id) ? { ...y, status: "confirmed" } : y)));
    toast.success(`تم الترحيل: اشتراكات ${fmt(sp.subs)} ← ${label("subs")} | مساهمات ${fmt(sp.cons)} ← ${label("cons")} | خارجية ${fmt(sp.ext)} ← ${label("ext")}`);
  };

  const spend = (e: React.FormEvent) => {
    e.preventDefault();
    const d = new FormData(e.currentTarget as HTMLFormElement);
    const amount = Number(d.get("a"));
    if (amount > balanceOf(treasury)) { setErr(`الرصيد غير كافٍ في ${label(treasury)} (المتوفر ${fmt(balanceOf(treasury))})`); return; }
    setErr("");
    setOuts((o) => [...o, { id: Date.now(), treasurer: String(d.get("t")), treasury, recipient: String(d.get("rc")), amount, date: String(d.get("d")), ref: String(d.get("r")) }]);
    toast.success("تم تسجيل الصرف وخصمه من الخزنة (تجريبي)");
    (e.currentTarget as HTMLFormElement).reset();
  };

  return (
    <div className="space-y-6">
      {section === "sum" && (
        <>
          <div className="grid gap-3 sm:grid-cols-3">
            {vaults.map((v) => (
              <div key={v.id} className="rounded-md border border-border bg-card p-5 text-center shadow-soft">
                <p className="flex items-center justify-center gap-1.5 text-sm font-black text-primary-deep"><Landmark className="size-4" />{v.label}</p>
                <p className="mt-2 text-3xl font-black">{fmt(v.balance)}</p>
                <p className="mt-1 text-xs text-muted-foreground">وارد {fmt(v.in)} — صرف {fmt(v.out)}</p>
              </div>
            ))}
          </div>
          <p className="rounded-md bg-primary-soft p-3 text-center font-black text-primary-deep">إجمالي أرصدة الخزن: {fmt(total)} ج.س</p>

          <Panel title="الأعضاء وحالة السداد" icon={<Users className="size-5" />} action={<PrintBtn />}>
            <Table head={["العضو", "الحالة", "الإشعارات (التاريخ — اشتراك / مساهمة)"]}>
              {members.map((m) => {
                const mine = payments.filter((p) => p.memberId === m.id);
                return (
                  <tr key={m.id}>
                    <td className="font-bold">{m.name}</td>
                    <td><Pill ok={paidThisMonth.has(m.id)} yes="سدّد" no="لم يسدّد" /></td>
                    <td className="text-xs text-muted-foreground">{mine.length ? mine.map((p) => `${p.date} — ${fmt(p.sub)} / ${fmt(p.con)}`).join(" | ") : "—"}</td>
                  </tr>
                );
              })}
            </Table>
          </Panel>
        </>
      )}

      {section === "vaults" && vaults.map((v) => (
        <Panel key={v.id} title={v.label} icon={<Landmark className="size-5" />} action={<span className="rounded-full bg-primary-soft px-3 py-1 text-sm font-black text-primary-deep">الرصيد {fmt(v.balance)}</span>}>
          <Table head={["التاريخ", "البيان", "وارد", "صرف"]} empty={movements(v.id).length === 0}>
            {movements(v.id).map((m, i) => (
              <tr key={i}><td>{m.date}</td><td className="font-bold">{m.what}</td><td className="text-primary-deep">{m.inn ? fmt(m.inn) : "—"}</td><td className="text-destructive">{m.out ? fmt(m.out) : "—"}</td></tr>
            ))}
          </Table>
        </Panel>
      ))}

      {section === "recv" && (
        <Panel title="استلام القروش من المتحصل (ترحيل تلقائي للخزن)" icon={<ArrowDownToLine className="size-5" />}>
          <Table head={["المتحصل", "التاريخ", "الإجمالي", "اشتراكات", "مساهمات", "خارجية", "العملية", "الصورة", "التأكيد"]}>
            {trs.map((t) => {
              const sp = split(t);
              return (
                <tr key={t.id}>
                  <td className="font-bold">{t.collector}</td><td>{t.date}</td><td className="font-bold">{fmt(t.amount)}</td>
                  <td>{fmt(sp.subs)}</td><td>{fmt(sp.cons)}</td><td>{fmt(sp.ext)}</td>
                  <td dir="ltr" className="text-right">{t.ref}</td><td><ImgThumb /></td>
                  <td>{t.confirmed
                    ? <span className="inline-flex items-center gap-1 text-xs font-bold text-primary-deep"><CheckCircle2 className="size-4" />رُحِّل للخزن</span>
                    : <Button size="sm" onClick={() => confirm(t)}>تأكيد الاستلام</Button>}
                  </td>
                </tr>
              );
            })}
          </Table>
        </Panel>
      )}

      {section === "out" && (
        <Panel title="القروش الطالعة من المالية" icon={<ArrowUpFromLine className="size-5" />}>
          <form className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3" onSubmit={spend}>
            <Field label="اسم الأمين المالي"><input name="t" className={inputCls} required defaultValue={settings.treasurerName} /></Field>
            <Field label="الصرف من خزنة">
              <select className={inputCls} value={treasury} onChange={(e) => setTreasury(e.target.value as Treasury)}>
                {vaults.map((v) => <option key={v.id} value={v.id}>{v.label} (المتوفر {fmt(v.balance)})</option>)}
              </select>
            </Field>
            <Field label="الجهة المستلمة"><select name="rc" className={inputCls}>{settings.recipients.map((r) => <option key={r}>{r}</option>)}</select></Field>
            <Field label="المبلغ (ج.س)"><input name="a" type="number" min="1" className={inputCls} required /></Field>
            <Field label="التاريخ"><input name="d" type="date" defaultValue={today()} className={inputCls} required /></Field>
            <Field label="رقم العملية"><input name="r" dir="ltr" className={inputCls} required /></Field>
            <FileField label="صورة الإشعار" />
            {err && <p role="alert" className="text-sm font-bold text-destructive sm:col-span-2 lg:col-span-3">{err}</p>}
            <div className="sm:col-span-2 lg:col-span-3"><Button type="submit">تسجيل الصرف</Button></div>
          </form>
          <div className="mt-5">
            <Table head={["الأمين المالي", "الخزنة", "الجهة", "المبلغ", "التاريخ", "العملية", "الإشعار"]}>
              {[...outs].reverse().map((o) => (
                <tr key={o.id}><td className="font-bold">{o.treasurer}</td><td>{label(o.treasury)}</td><td>{o.recipient}</td><td>{fmt(o.amount)}</td><td>{o.date}</td><td dir="ltr" className="text-right">{o.ref}</td><td><ImgThumb /></td></tr>
              ))}
            </Table>
          </div>
        </Panel>
      )}

      {section === "part" && <PartnershipPanel source="finance" />}
    </div>
  );
}
