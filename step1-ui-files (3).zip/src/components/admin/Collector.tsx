import { useState } from "react";
import { Handshake, MessageCircle, Receipt, Send } from "lucide-react";
import { toast } from "sonner";
import { members, fmt, fillTemplate, TREASURIES, type PaymentNotice, type PayStatus, type Partnership } from "@/lib/mock-admin";
import { Button } from "@/components/ui/button";
import { Field, FileField, Panel, Stat, Table, inputCls, mockSubmit } from "./ui";
import { useAdminStore } from "./store";

const today = () => new Date().toISOString().slice(0, 10);
const nameOf = (p: PaymentNotice) => (p.memberId ? members.find((m) => m.id === p.memberId)?.name : p.payer) ?? "—";
const digits = (v: string) => v.replace(/\D/g, "");
const intl = (phone: string) => { const d = digits(phone); return d.startsWith("249") ? d : "249" + d.replace(/^0/, ""); };
const detailsText = (sub: number, months: number, con: number, desc: string, fee: number) => {
  const parts: string[] = [];
  if (sub > 0) parts.push(months > 1 ? `اشتراك مقدَّم (${months} أشهر)` : sub < fee * Math.max(months, 1) ? "اشتراك جزئي" : "اشتراك شهري");
  if (con > 0) parts.push(`مساهمة${desc ? ` (${desc})` : ""}`);
  return parts.join(" + ");
};
const STATUS: Record<PayStatus, { label: string; cls: string }> = {
  recorded: { label: "في العهدة", cls: "bg-accent-soft text-accent" },
  sent: { label: "مُرسل للمالية", cls: "bg-secondary text-muted-foreground" },
  confirmed: { label: "مؤكَّد", cls: "bg-primary-soft text-primary-deep" },
};
const StatusPill = ({ s }: { s: PayStatus }) => <span className={`inline-flex rounded-full px-2.5 py-0.5 text-xs font-bold ${STATUS[s].cls}`}>{STATUS[s].label}</span>;

export function Collector({ section }: { section: string }) {
  const { payments: pays, setPayments: setPays, transfers: trs, setTransfers: setTrs, partnerships: parts, setPartnerships: setParts, settings } = useAdminStore();
  const fee = settings.fee;
  const [name, setName] = useState("");
  const [manualPhone, setManualPhone] = useState("");
  const [date, setDate] = useState(today());
  const [ref, setRef] = useState("");
  const [months, setMonths] = useState(1);
  const [sub, setSub] = useState(fee);
  const [con, setCon] = useState(0);
  const [desc, setDesc] = useState("");
  const [wantMsg, setWantMsg] = useState(true);
  const [msgOverride, setMsgOverride] = useState<string | null>(null);
  const [err, setErr] = useState("");
  const [last, setLast] = useState<{ id: number; msg: string; phone: string } | null>(null);
  const [picked, setPicked] = useState<number[] | null>(null);
  const [pickedP, setPickedP] = useState<number[] | null>(null);
  const [trRef, setTrRef] = useState("");
  const [trErr, setTrErr] = useState("");

  // العهدة = إشعارات الدفع + الشراكات التي سجّلها المتحصل ولم يرسلها بعد
  const custody = pays.filter((p) => p.status === "recorded");
  const custodyP = parts.filter((x) => x.source === "collector" && x.status === "recorded");
  const sel = picked ?? custody.map((p) => p.id); // الافتراضي: كل ما في العهدة
  const selP = pickedP ?? custodyP.map((x) => x.id);
  const selPays = custody.filter((p) => sel.includes(p.id));
  const subSum = selPays.reduce((s, p) => s + p.sub, 0);
  const conSum = selPays.reduce((s, p) => s + p.con, 0);
  const extSum = custodyP.filter((x) => selP.includes(x.id)).reduce((s, x) => s + x.amount, 0);
  const selSum = subSum + conSum + extSum;
  const inCustody = {
    subs: custody.reduce((s, p) => s + p.sub, 0), cons: custody.reduce((s, p) => s + p.con, 0), ext: custodyP.reduce((s, x) => s + x.amount, 0),
  };
  const sum = (st: PayStatus) => pays.filter((p) => p.status === st).reduce((s, p) => s + p.amount, 0)
    + parts.filter((x) => x.source === "collector" && x.status === st).reduce((s, x) => s + x.amount, 0);

  // العضو: يُبحث عنه بالاسم في شؤون العضوية ويظهر رقم واتسابه تلقائياً
  const member = members.find((m) => m.name === name.trim());
  const phone = member ? member.whatsapp : manualPhone;
  const total = sub + con;
  const partial = sub > 0 && sub < fee * months;
  const details = detailsText(sub, months, con, desc, fee);
  const defaultMsg = fillTemplate(settings.collectorMsg, {
    "الاسم": name.trim() || "(اسم العضو)", "المبلغ": fmt(total), "التاريخ": date, "رقم العملية": ref.trim() || "—", "التفاصيل": details || "مساهمتك",
  });
  const msg = msgOverride ?? defaultMsg;

  const record = (e: React.FormEvent) => {
    e.preventDefault();
    const r = ref.trim();
    if (!name.trim()) { setErr("اكتب اسم العضو أو الدافع"); return; }
    if (total <= 0) { setErr("أدخل مبلغ الاشتراك أو المساهمة (أو الاثنين)"); return; }
    if (pays.some((p) => p.ref.toLowerCase() === r.toLowerCase())) { setErr("رقم العملية مسجَّل من قبل — لا يمكن تسجيل إشعارين بنفس الرقم"); return; }
    setErr("");
    const id = Date.now();
    setPays((p) => [...p, {
      id, memberId: member?.id ?? 0, payer: member ? undefined : name.trim(), phone, date, ref: r,
      sub, con, amount: total, desc: con > 0 ? desc : "", months: sub > 0 ? months : 0, status: "recorded",
    }]);
    if (wantMsg && phone) setLast({ id, msg, phone }); else setLast(null);
    setName(""); setManualPhone(""); setRef(""); setCon(0); setDesc(""); setMonths(1); setSub(fee); setMsgOverride(null);
    toast.success("تم تسجيل الإشعار (تجريبي)");
  };

  const send = (e: React.FormEvent) => {
    e.preventDefault();
    const d = new FormData(e.currentTarget as HTMLFormElement);
    const r = trRef.trim();
    if (sel.length + selP.length === 0) { setTrErr("اختر بنداً واحداً على الأقل"); return; }
    if (trs.some((t) => t.ref.toLowerCase() === r.toLowerCase())) { setTrErr("رقم عملية التحويل مسجَّل من قبل"); return; }
    setTrErr("");
    setTrs((t) => [...t, { id: Date.now(), collector: String(d.get("c")), date: String(d.get("dt")), amount: selSum, ref: r, confirmed: false, paymentIds: sel, partnerIds: selP }]);
    setPays((p) => p.map((x) => (sel.includes(x.id) ? { ...x, status: "sent" } : x)));
    setParts((p) => p.map((x) => (selP.includes(x.id) ? { ...x, status: "sent" } : x)));
    setPicked(null); setPickedP(null); setTrRef(""); toast.success("تم إرسال التحويل للأمين المالي (تجريبي)");
  };

  return (
    <div className="space-y-6">
      {section === "members" && <Panel title="الأعضاء (من شؤون العضوية)">
        <Table head={["الاسم", "الهاتف", "واتساب"]}>
          {members.map((m) => (
            <tr key={m.id}><td className="font-bold">{m.name}</td><td dir="ltr" className="text-right">{m.phone}</td><td dir="ltr" className="text-right">{m.whatsapp}</td></tr>
          ))}
        </Table>
      </Panel>}

      {section === "notice" && (
        <>
          <div className="grid grid-cols-3 gap-3">
            {TREASURIES.map((t) => <Stat key={t.id} label={`عهدتي: ${t.label.replace("خزنة ", "")}`} value={fmt(inCustody[t.id])} tone={t.id === "cons" ? "gold" : "primary"} />)}
          </div>
          <p className="text-center text-xs text-muted-foreground">مُرسل بانتظار تأكيد المالية: {fmt(sum("sent"))} — مؤكَّد: {fmt(sum("confirmed"))}</p>

          <Panel title="إدراج إشعار دفع" icon={<Receipt className="size-5" />}>
            <form className="space-y-5" onSubmit={record}>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                <Field label="اسم العضو (اكتب أو اختر)">
                  <input className={inputCls} list="member-names" required value={name} onChange={(e) => setName(e.target.value)} placeholder="ابدأ بكتابة الاسم..." />
                  <datalist id="member-names">{members.map((m) => <option key={m.id} value={m.name} />)}</datalist>
                </Field>
                <Field label={member ? "رقم الواتساب (من شؤون العضوية)" : "رقم الواتساب"}>
                  {member
                    ? <input className={`${inputCls} bg-primary-soft font-bold`} dir="ltr" readOnly value={member.whatsapp} />
                    : <input className={inputCls} dir="ltr" value={manualPhone} onChange={(e) => setManualPhone(e.target.value)} placeholder="09xxxxxxxx" />}
                </Field>
                <p className={`self-end rounded-md px-3 py-2 text-xs font-bold ${member ? "bg-primary-soft text-primary-deep" : name.trim() ? "bg-accent-soft text-accent" : "bg-secondary text-muted-foreground"}`}>
                  {member ? "عضو مسجَّل في شؤون العضوية" : name.trim() ? "غير مسجَّل في شؤون العضوية — أدخل الرقم يدوياً" : "اكتب الاسم ليظهر الرقم تلقائياً"}
                </p>
                <Field label="تاريخ الإشعار"><input type="date" className={inputCls} required value={date} onChange={(e) => setDate(e.target.value)} /></Field>
                <Field label="رقم العملية"><input dir="ltr" className={inputCls} required value={ref} onChange={(e) => setRef(e.target.value)} /></Field>
              </div>

              <div className="grid gap-4 rounded-md border border-border p-4 sm:grid-cols-2">
                <div className="space-y-3">
                  <p className="text-sm font-black text-primary-deep">الاشتراك الشهري (اختياري)</p>
                  <Field label="عدد الأشهر (أكثر من 1 = دفع مقدَّم)">
                    <input type="number" min={1} max={12} className={inputCls} value={months} onChange={(e) => { const n = Math.max(1, Number(e.target.value)); setMonths(n); setSub(fee * n); }} />
                  </Field>
                  <Field label="مبلغ الاشتراك (ج.س) — اتركه 0 إن لم يدفع اشتراكاً">
                    <input type="number" min={0} className={inputCls} value={sub} onChange={(e) => setSub(Number(e.target.value))} />
                  </Field>
                  {sub > 0 && <p className={`rounded-md px-3 py-2 text-xs font-bold ${partial ? "bg-destructive/10 text-destructive" : "bg-primary-soft text-primary-deep"}`}>
                    {partial ? `دفع جزئي — المتبقي ${fmt(fee * months - sub)} ج.س` : months > 1 ? `دفع مقدَّم لـ ${months} أشهر` : "اشتراك كامل لشهر واحد"}
                  </p>}
                </div>
                <div className="space-y-3">
                  <p className="text-sm font-black text-accent">المساهمة (اختيارية)</p>
                  <Field label="مبلغ المساهمة (ج.س)"><input type="number" min={0} className={inputCls} value={con} onChange={(e) => setCon(Number(e.target.value))} /></Field>
                  <Field label="نوع / وصف المساهمة"><input className={inputCls} value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="صدقة، صدقة لروح فلان..." /></Field>
                </div>
              </div>
              <p className="rounded-md bg-secondary p-3 text-center text-lg font-black text-primary-deep">إجمالي الإشعار: {fmt(total)} ج.س</p>

              <div className="space-y-3 rounded-md border border-accent/30 bg-accent-soft/50 p-4">
                <label className="flex items-center gap-2 text-sm font-black text-accent">
                  <input type="checkbox" className="size-4" checked={wantMsg} onChange={(e) => setWantMsg(e.target.checked)} />
                  تجهيز رسالة واتساب للعضو بعد التسجيل
                </label>
                {wantMsg && (
                  <>
                    <textarea rows={4} className={`${inputCls} !h-auto py-3 leading-loose`} value={msg} onChange={(e) => setMsgOverride(e.target.value)} />
                    <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                      <span>الرسالة الافتراضية تُعدَّل من «الإعدادات». المتغيرات: {"{الاسم} {المبلغ} {التاريخ} {رقم العملية} {التفاصيل}"}</span>
                      {msgOverride !== null && <button type="button" className="font-bold text-primary underline" onClick={() => setMsgOverride(null)}>إعادة الافتراضية</button>}
                    </div>
                  </>
                )}
              </div>

              {err && <p role="alert" className="text-sm font-bold text-destructive">{err}</p>}
              <Button type="submit">تسجيل الإشعار</Button>
            </form>
          </Panel>

          {last && (
            <Panel title="رسالة الواتساب جاهزة" icon={<MessageCircle className="size-5" />}>
              <p className="rounded-md border border-border bg-secondary/50 p-4 text-sm leading-loose">{last.msg}</p>
              <Button asChild variant="gold" size="sm" className="mt-3">
                <a href={`https://wa.me/${intl(last.phone)}?text=${encodeURIComponent(last.msg)}`} target="_blank" rel="noreferrer"><MessageCircle />فتح واتساب</a>
              </Button>
            </Panel>
          )}

          <Panel title="إشعاراتي">
            <Table head={["الدافع", "التاريخ", "العملية", "الاشتراك الشهري", "المساهمة", "الإجمالي", "الحالة"]}>
              {[...pays].reverse().map((p) => (
                <tr key={p.id}>
                  <td className="font-bold">{nameOf(p)}</td><td>{p.date}</td><td dir="ltr" className="text-right">{p.ref}</td>
                  <td className="font-bold text-primary-deep">{p.sub > 0 ? <>{fmt(p.sub)}{p.months > 1 && <small className="block font-normal text-muted-foreground">مقدَّم ({p.months} أشهر)</small>}</> : "—"}</td>
                  <td className="font-bold text-accent">{p.con > 0 ? <>{fmt(p.con)}{p.desc && <small className="block font-normal text-muted-foreground">{p.desc}</small>}</> : "—"}</td>
                  <td>{fmt(p.amount)}</td>
                  <td><StatusPill s={p.status} /></td>
                </tr>
              ))}
            </Table>
          </Panel>
        </>
      )}

      {section === "send" && (
        <>
          <Panel title="إرسال القروش للأمين المالي" icon={<Send className="size-5" />}>
            <p className="mb-3 text-xs leading-relaxed text-muted-foreground">
              اختر ما يغطيه هذا التحويل؛ يُحسب المبلغ تلقائياً. وعند تأكيد المالية يُرحَّل كل جزء إلى الخزنة التي تحمل اسمه: الاشتراكات إلى خزنة الاشتراكات الشهرية، والمساهمات إلى خزنة مساهمات الأعضاء، والشراكات إلى خزنة الشراكات الخارجية.
            </p>
            {custody.length + custodyP.length === 0 ? (
              <p className="rounded-md bg-secondary/60 p-4 text-center text-sm text-muted-foreground">لا شيء في عهدتك. كل ما سجّلته أُرسل للمالية.</p>
            ) : (
              <form className="space-y-4" onSubmit={send}>
                {custody.length > 0 && (
                  <Table head={["", "العضو", "التاريخ", "العملية", "الاشتراك", "المساهمة"]}>
                    {custody.map((p) => (
                      <tr key={p.id}>
                        <td><input type="checkbox" className="size-4" checked={sel.includes(p.id)} onChange={(e) => setPicked(e.target.checked ? [...sel, p.id] : sel.filter((x) => x !== p.id))} /></td>
                        <td className="font-bold">{nameOf(p)}</td><td>{p.date}</td><td dir="ltr" className="text-right">{p.ref}</td>
                        <td>{p.sub > 0 ? fmt(p.sub) : "—"}</td><td>{p.con > 0 ? fmt(p.con) : "—"}</td>
                      </tr>
                    ))}
                  </Table>
                )}
                {custodyP.length > 0 && (
                  <Table head={["", "الجهة (شراكة خارجية)", "التاريخ", "العملية", "المبلغ"]}>
                    {custodyP.map((x) => (
                      <tr key={x.id}>
                        <td><input type="checkbox" className="size-4" checked={selP.includes(x.id)} onChange={(e) => setPickedP(e.target.checked ? [...selP, x.id] : selP.filter((y) => y !== x.id))} /></td>
                        <td className="font-bold">{x.party}</td><td>{x.date}</td><td dir="ltr" className="text-right">{x.ref}</td><td>{fmt(x.amount)}</td>
                      </tr>
                    ))}
                  </Table>
                )}
                <div className="grid grid-cols-3 gap-3">
                  <Stat label="إلى خزنة الاشتراكات" value={fmt(subSum)} />
                  <Stat label="إلى خزنة المساهمات" value={fmt(conSum)} tone="gold" />
                  <Stat label="إلى خزنة الشراكات" value={fmt(extSum)} />
                </div>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  <Field label="اسم المتحصل"><input name="c" className={inputCls} required defaultValue={settings.collectorName} /></Field>
                  <Field label="التاريخ"><input name="dt" type="date" defaultValue={today()} className={inputCls} required /></Field>
                  <Field label="إجمالي التحويل (يُحسب تلقائياً)"><input className={`${inputCls} bg-secondary font-black`} readOnly value={fmt(selSum)} /></Field>
                  <Field label="رقم عملية التحويل"><input dir="ltr" className={inputCls} required value={trRef} onChange={(e) => setTrRef(e.target.value)} /></Field>
                  <FileField label="صورة الإشعار" />
                </div>
                {trErr && <p role="alert" className="text-sm font-bold text-destructive">{trErr}</p>}
                <Button type="submit">إرسال ({sel.length + selP.length} بنود)</Button>
              </form>
            )}
          </Panel>
          <Panel title="تحويلاتي">
            <Table head={["المتحصل", "التاريخ", "المبلغ", "العملية", "البنود", "الحالة"]}>
              {[...trs].reverse().map((t) => (
                <tr key={t.id}><td className="font-bold">{t.collector}</td><td>{t.date}</td><td>{fmt(t.amount)}</td><td dir="ltr" className="text-right">{t.ref}</td><td>{t.paymentIds.length + t.partnerIds.length}</td>
                  <td>{t.confirmed ? "تم الاستلام والترحيل" : "بانتظار المالية"}</td></tr>
              ))}
            </Table>
          </Panel>
        </>
      )}

      {section === "part" && <PartnershipPanel source="collector" />}
    </div>
  );
}

const PSTAT: Record<PayStatus, string> = { recorded: "في العهدة", sent: "مُرسل للمالية", confirmed: "مؤكَّد (في الخزنة)" };

// يُستخدم في التحصيل (تمر بالعهدة) وفي المالية (تُؤكَّد فوراً وتدخل خزنة الشراكات الخارجية)
export function PartnershipPanel({ source }: { source: Partnership["source"] }) {
  const { partnerships: list, setPartnerships: setList } = useAdminStore();
  const shown = source === "collector" ? list.filter((x) => x.source === "collector") : list;
  return (
    <Panel title="الشراكات والدعمات الخارجية" icon={<Handshake className="size-5" />}>
      <p className="mb-3 text-xs leading-relaxed text-muted-foreground">
        {source === "collector"
          ? "تدخل عهدتك وتُرسل مع التحويل، ثم تُرحَّل تلقائياً إلى خزنة الشراكات الخارجية عند تأكيد المالية."
          : "تُسجَّل هنا مباشرة فتدخل خزنة الشراكات الخارجية فوراً."}
      </p>
      <form className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3" onSubmit={(e) => {
        mockSubmit("تم تسجيل الدعم")(e);
        const d = new FormData(e.currentTarget as HTMLFormElement);
        setList((p) => [...p, { id: Date.now(), party: String(d.get("p")), type: String(d.get("t")), amount: Number(d.get("a")), ref: String(d.get("r")), date: today(), status: source === "finance" ? "confirmed" : "recorded", source }]);
        (e.currentTarget as HTMLFormElement).reset();
      }}>
        <Field label="اسم الجهة / المكان"><input name="p" className={inputCls} placeholder="قروة الخير، دعم التكية..." required /></Field>
        <Field label="نوع الشراكة"><input name="t" className={inputCls} placeholder="شراكة، دعم مباشر..." required /></Field>
        <Field label="المبلغ (ج.س)"><input name="a" type="number" min="1" className={inputCls} required /></Field>
        <Field label="رقم العملية"><input name="r" dir="ltr" className={inputCls} required /></Field>
        <FileField label="صورة الإشعار" optional />
        <div className="flex items-end"><Button type="submit">تسجيل</Button></div>
      </form>
      <div className="mt-5">
        <Table head={["الجهة", "النوع", "المبلغ", "العملية", "التاريخ", "الحالة"]}>
          {[...shown].reverse().map((p) => (
            <tr key={p.id}><td className="font-bold">{p.party}</td><td>{p.type}</td><td>{fmt(p.amount)}</td><td dir="ltr" className="text-right">{p.ref}</td><td>{p.date}</td><td className="text-xs">{PSTAT[p.status]}</td></tr>
          ))}
        </Table>
      </div>
    </Panel>
  );
}
