import { createContext, useContext, useState, type Dispatch, type ReactNode, type SetStateAction } from "react";
import { DEFAULT_SETTINGS, outflows as seedOut, partnerships as seedPart, payments as seedPay, transfers as seedTr, type AppSettings, type Outflow, type Partnership, type PaymentNotice, type Transfer } from "@/lib/mock-admin";

/** حالة مشتركة بين التحصيل والمالية والمراجعة (إشعارات الدفع والتحويلات). في المرحلة الثانية تُستبدل بجداول Supabase. */
type Store = {
  payments: PaymentNotice[]; setPayments: Dispatch<SetStateAction<PaymentNotice[]>>;
  transfers: Transfer[]; setTransfers: Dispatch<SetStateAction<Transfer[]>>;
  partnerships: Partnership[]; setPartnerships: Dispatch<SetStateAction<Partnership[]>>;
  outflows: Outflow[]; setOutflows: Dispatch<SetStateAction<Outflow[]>>;
  settings: AppSettings; setSettings: Dispatch<SetStateAction<AppSettings>>;
};
const Ctx = createContext<Store | null>(null);

export function AdminStoreProvider({ children }: { children: ReactNode }) {
  const [payments, setPayments] = useState(seedPay);
  const [transfers, setTransfers] = useState(seedTr);
  const [partnerships, setPartnerships] = useState(seedPart);
  const [outflows, setOutflows] = useState(seedOut);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  return <Ctx.Provider value={{ payments, setPayments, transfers, setTransfers, partnerships, setPartnerships, outflows, setOutflows, settings, setSettings }}>{children}</Ctx.Provider>;
}

export function useAdminStore() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useAdminStore must be used inside AdminStoreProvider");
  return c;
}
