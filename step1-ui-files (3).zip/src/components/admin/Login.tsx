import { useState } from "react";
import { LogIn, Wheat } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Account } from "@/lib/mock-admin";
import { Field, inputCls } from "./ui";

export function Login({ accounts, onEnter }: { accounts: Account[]; onEnter: (a: Account) => void }) {
  const [user, setUser] = useState("");
  const [pass, setPass] = useState("");
  const [err, setErr] = useState("");

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const acc = accounts.find((a) => a.username.toLowerCase() === user.trim().toLowerCase() && a.password === pass);
    if (!acc) return setErr("اسم المستخدم أو كلمة المرور غير صحيحة");
    if (!acc.active) return setErr("هذا الحساب موقوف، راجع الكنترول");
    setErr("");
    onEnter(acc); // تُفتح له واجهة دوره فقط
  };

  return (
    <div className="mx-auto grid min-h-screen max-w-4xl items-center gap-8 px-4 py-10 lg:grid-cols-2">
      <form onSubmit={submit} className="rounded-md border border-border bg-card p-7 shadow-lift">
        <div className="mb-6 flex items-center gap-3">
          <span className="flex size-12 items-center justify-center rounded-md bg-primary-soft text-primary-deep"><Wheat /></span>
          <div>
            <h1 className="text-2xl font-black text-primary-deep">الإدارة</h1>
            <p className="text-xs text-muted-foreground">أدخل اسم المستخدم وكلمة المرور اللذين أعطاهما لك الكنترول</p>
          </div>
        </div>
        <div className="space-y-4">
          <Field label="اسم المستخدم"><input className={inputCls} dir="ltr" value={user} onChange={(e) => setUser(e.target.value)} autoComplete="username" /></Field>
          <Field label="كلمة المرور"><input className={inputCls} dir="ltr" type="password" value={pass} onChange={(e) => setPass(e.target.value)} autoComplete="current-password" /></Field>
          {err && <p role="alert" className="text-sm font-bold text-destructive">{err}</p>}
          <Button type="submit" className="w-full" size="lg"><LogIn />دخول</Button>
          <a href="/" className="block text-center text-sm font-bold text-primary hover:underline">العودة إلى الموقع</a>
        </div>
      </form>

      <div className="rounded-md border border-accent/40 bg-accent-soft p-6">
        <p className="text-sm font-black text-accent">حساب الكنترول التجريبي (للتصميم فقط)</p>
        <p className="mt-2 text-sm leading-loose text-muted-foreground">
          المستخدم: <b dir="ltr">control</b> — كلمة المرور: <b dir="ltr">Control#123</b>
          <br />ادخل به ثم أنشئ حسابات الإدارات من «الحسابات»، وجرّب الدخول بكل حساب. سيُحذف هذا الجزء عند ربط الدخول الحقيقي.
        </p>
        <Button type="button" variant="gold" size="sm" className="mt-3" onClick={() => { setUser("control"); setPass("Control#123"); }}>تعبئة تلقائية</Button>
      </div>
    </div>
  );
}
