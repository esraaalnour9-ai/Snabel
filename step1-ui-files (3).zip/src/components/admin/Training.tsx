import { useState } from "react";
import { GraduationCap, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { trainings as seed } from "@/lib/mock-admin";
import { Field, Panel, Table, inputCls, mockSubmit } from "./ui";
import { useAdminStore } from "./store";

export function Training({ section }: { section: string }) {
  const { settings } = useAdminStore();
  const [list, setList] = useState(seed);
  return (
    <div className="space-y-6">
      {section === "new" && (
      <>
      <Panel title="إضافة فرصة / ورشة / دورة" icon={<GraduationCap className="size-5" />}>
        <form className="grid gap-4 sm:grid-cols-2" onSubmit={(e) => {
          mockSubmit("تمت إضافة الفرصة")(e);
          const d = new FormData(e.currentTarget as HTMLFormElement);
          setList((l) => [{ id: Date.now(), title: String(d.get("t")), audience: String(d.get("a")), details: String(d.get("s")), link: String(d.get("l")) }, ...l]);
          (e.currentTarget as HTMLFormElement).reset();
        }}>
          <Field label="اسم الدورة / الورشة"><input name="t" required className={inputCls} /></Field>
          <Field label="الفئة المستهدفة"><input name="a" required className={inputCls} /></Field>
          <Field label="التفاصيل" className="sm:col-span-2"><textarea name="s" required rows={4} className={`${inputCls} !h-auto py-3`} /></Field>
          <Field label="رابط استمارة التقديم" className="sm:col-span-2"><input name="l" type="url" dir="ltr" required placeholder="https://forms.gle/..." defaultValue={settings.trainingLink} className={inputCls} /></Field>
          <div className="sm:col-span-2"><Button type="submit">نشر الفرصة</Button></div>
        </form>
      </Panel>
      </>
      )}
      {section === "list" && (
      <>
      <Panel title="الفرص المعروضة للعامة">
        <Table head={["العنوان", "الفئة", "التفاصيل", "الاستمارة", ""]}>
          {list.map((t) => (
            <tr key={t.id}>
              <td className="font-bold">{t.title}</td><td>{t.audience}</td><td className="text-muted-foreground">{t.details}</td>
              <td><a href={t.link} target="_blank" rel="noreferrer" className="text-primary underline">فتح</a></td>
              <td><button type="button" aria-label="حذف" className="text-destructive" onClick={() => setList((l) => l.filter((x) => x.id !== t.id))}><Trash2 className="size-4" /></button></td>
            </tr>
          ))}
        </Table>
      </Panel>
      </>
      )}
    </div>
  );
}
