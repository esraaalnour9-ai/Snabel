import { useState, type ReactNode } from "react";
import { Printer, Upload } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export const inputCls =
  "h-11 w-full rounded-md border border-input bg-card px-3 text-sm text-foreground outline-none transition focus:border-primary focus:ring-2 focus:ring-ring/30";

export function Panel({ title, icon, action, children, className }: {
  title: string; icon?: ReactNode; action?: ReactNode; children: ReactNode; className?: string;
}) {
  return (
    <section className={cn("rounded-md border border-border bg-card p-5 shadow-soft sm:p-6", className)}>
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <h3 className="flex items-center gap-2 text-lg font-black text-primary-deep">
          {icon}{title}
        </h3>
        {action}
      </div>
      {children}
    </section>
  );
}

export function Stat({ label, value, tone = "primary" }: { label: string; value: ReactNode; tone?: "primary" | "gold" | "danger" }) {
  const t = tone === "gold" ? "border-accent/40 bg-accent-soft text-accent"
    : tone === "danger" ? "border-destructive/30 bg-destructive/10 text-destructive"
    : "border-primary/20 bg-primary-soft text-primary-deep";
  return (
    <div className={cn("rounded-md border p-4 text-center", t)}>
      <p className="text-2xl font-black sm:text-3xl">{value}</p>
      <p className="mt-1 text-xs font-bold opacity-80 sm:text-sm">{label}</p>
    </div>
  );
}

export function Table({ head, children, empty }: { head: string[]; children: ReactNode; empty?: boolean }) {
  return (
    <div className="overflow-x-auto rounded-md border border-border">
      <table className="w-full min-w-[560px] text-right text-sm">
        <thead className="bg-secondary text-xs text-muted-foreground">
          <tr>{head.map((h) => <th key={h} className="whitespace-nowrap px-3 py-2.5 font-bold">{h}</th>)}</tr>
        </thead>
        <tbody className="divide-y divide-border [&_td]:px-3 [&_td]:py-2.5">{children}</tbody>
      </table>
      {empty && <p className="p-6 text-center text-sm text-muted-foreground">لا توجد بيانات.</p>}
    </div>
  );
}

export function Field({ label, children, className }: { label: string; children: ReactNode; className?: string }) {
  return (
    <label className={cn("block space-y-1.5", className)}>
      <span className="text-xs font-bold text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}

export function FileField({ label, accept = "image/*", optional }: { label: string; accept?: string; optional?: boolean }) {
  const [name, setName] = useState("");
  return (
    <Field label={`${label}${optional ? " (اختياري)" : ""}`}>
      <span className="flex h-11 cursor-pointer items-center gap-2 rounded-md border border-dashed border-primary/40 bg-primary-soft/50 px-3 text-sm text-primary-deep hover:bg-primary-soft">
        <Upload className="size-4 shrink-0" />
        <span className="truncate">{name || "اختر ملفاً"}</span>
        <input type="file" accept={accept} className="sr-only" onChange={(e) => setName(e.target.files?.[0]?.name ?? "")} />
      </span>
    </Field>
  );
}

export function PrintBtn({ label = "طباعة / تصدير PDF" }: { label?: string }) {
  return (
    <Button type="button" variant="outline" size="sm" onClick={() => toast.info("تجريبي: سيتم توليد ملف PDF فعلي في المرحلة القادمة")}>
      <Printer />{label}
    </Button>
  );
}

export function Pill({ ok, yes, no }: { ok: boolean; yes: string; no: string }) {
  return (
    <span className={cn("inline-flex rounded-full px-2.5 py-0.5 text-xs font-bold", ok ? "bg-primary-soft text-primary-deep" : "bg-destructive/10 text-destructive")}>
      {ok ? yes : no}
    </span>
  );
}

export const mockSubmit = (msg: string) => (e: React.FormEvent) => {
  e.preventDefault();
  toast.success(`${msg} (بيانات تجريبية لا تُحفظ)`);
};

export const ImgThumb = () => (
  <div className="flex size-10 items-center justify-center rounded bg-secondary text-[10px] text-muted-foreground">صورة</div>
);
