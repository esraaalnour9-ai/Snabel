import { AlertTriangle, CheckCircle2 } from "lucide-react";
import { projects, total, fmt } from "@/lib/mock-admin";
import { useAdminStore } from "./store";
import { Panel, PrintBtn, Table } from "./ui";

export function Auditor({ section }: { section: string }) {
  const { payments, transfers, partnerships, outflows, settings } = useAdminStore();
  const collected = payments.reduce((s, p) => s + p.amount, 0) + partnerships.filter((x) => x.source === "collector").reduce((s, x) => s + x.amount, 0);
  const sentByCollector = transfers.reduce((s, t) => s + t.amount, 0);
  const receivedByFinance = transfers.filter((t) => t.confirmed).reduce((s, t) => s + t.amount, 0);
  const ext = partnerships.reduce((s, p) => s + p.amount, 0);
  const out = outflows.reduce((s, o) => s + o.amount, 0);
  const spent = projects.reduce((s, p) => s + total(p.expenses), 0);

  const checks = [
    { name: "التحصيل ↔ المرسل للمالية", a: collected, b: sentByCollector, la: "إجمالي إشعارات المتحصل", lb: "إجمالي ما أرسله المتحصل" },
    { name: "المرسل ↔ المستلم في المالية", a: sentByCollector, b: receivedByFinance, la: "ما أرسله المتحصل", lb: "ما أكدت المالية استلامه" },
    { name: "الصرف من المالية ↔ منصرفات المشاريع", a: out, b: spent, la: "الطالع من المالية", lb: "إجمالي منصرفات المشاريع والتكية" },
  ];

  return (
    <div className="space-y-6">
      {section === "sum" && (
      <>
      <Panel title="ملخصات الإدارات" action={<PrintBtn label="تقرير المراجعة PDF" />}>
        <Table head={["الإدارة", "البند", "المبلغ"]}>
          <tr><td className="font-bold">التحصيل</td><td>إجمالي إشعارات الأعضاء</td><td>{fmt(collected)}</td></tr>
          <tr><td className="font-bold">المالية</td><td>المستلم من المتحصل (مؤكد)</td><td>{fmt(receivedByFinance)}</td></tr>
          <tr><td className="font-bold">المالية</td><td>الدعمات والشراكات الخارجية</td><td>{fmt(ext)}</td></tr>
          <tr><td className="font-bold">المالية</td><td>الطالع للمشاريع/التكية</td><td>{fmt(out)}</td></tr>
          <tr><td className="font-bold">المشاريع والتكية</td><td>إجمالي المنصرفات</td><td>{fmt(spent)}</td></tr>
        </Table>
      </Panel>

      </>
      )}
      {section === "match" && (
      <>
      <Panel title="شاشة المطابقة">
        <div className="space-y-3">
          {checks.map((c) => {
            const diff = c.a - c.b;
            const ok = Math.abs(diff) <= settings.tolerance;
            return (
              <div key={c.name} className={`rounded-md border p-4 ${ok ? "border-primary/30 bg-primary-soft/50" : "border-destructive/30 bg-destructive/5"}`}>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="font-black text-primary-deep">{c.name}</p>
                  <span className={`inline-flex items-center gap-1 text-sm font-bold ${ok ? "text-primary-deep" : "text-destructive"}`}>
                    {ok ? <CheckCircle2 className="size-4" /> : <AlertTriangle className="size-4" />}
                    {ok ? "متطابق" : `فرق ${fmt(Math.abs(diff))} ج.س`}
                  </span>
                </div>
                <dl className="mt-2 grid gap-1 text-sm text-muted-foreground sm:grid-cols-2">
                  <div>{c.la}: <b className="text-foreground">{fmt(c.a)}</b></div>
                  <div>{c.lb}: <b className="text-foreground">{fmt(c.b)}</b></div>
                </dl>
              </div>
            );
          })}
        </div>
      </Panel>
      </>
      )}
    </div>
  );
}
