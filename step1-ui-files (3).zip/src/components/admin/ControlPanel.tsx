import { useState } from "react";
import { KeyRound, Plus, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { ROLES, roleLabel, type Account, type Role } from "@/lib/mock-admin";
import { Field, Panel, Table, inputCls } from "./ui";

const empty = { name: "", username: "", password: "", role: "collector" as Role };

export function ControlPanel({ accounts, setAccounts }: { accounts: Account[]; setAccounts: (f: (a: Account[]) => Account[]) => void }) {
  const [pwFor, setPwFor] = useState<number | null>(null);
  const [newPw, setNewPw] = useState("");
  const [f, setF] = useState(empty);
  const [err, setErr] = useState("");

  const create = (e: React.FormEvent) => {
    e.preventDefault();
    if (accounts.some((a) => a.username.toLowerCase() === f.username.trim().toLowerCase())) return setErr("اسم المستخدم مستخدم من قبل");
    setErr("");
    setAccounts((a) => [...a, { id: Date.now(), name: f.name || f.username, username: f.username.trim(), password: f.password, role: f.role, active: true }]);
    toast.success(`تم إنشاء حساب ${roleLabel(f.role)} — جرّب الدخول به`);
    setF(empty);
  };

  return (
    <div className="space-y-6">
      <Panel title="إضافة حساب جهة جديدة" icon={<Plus className="size-5" />}>
        <form className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4" onSubmit={create}>
          <Field label="اسم صاحب الحساب"><input className={inputCls} value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
          <Field label="اسم المستخدم"><input className={inputCls} dir="ltr" required value={f.username} onChange={(e) => setF({ ...f, username: e.target.value })} /></Field>
          <Field label="كلمة المرور الأولية"><input className={inputCls} dir="ltr" required minLength={4} value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} /></Field>
          <Field label="الدور">
            <select className={inputCls} value={f.role} onChange={(e) => setF({ ...f, role: e.target.value as Role })}>
              {ROLES.filter((r) => r.id !== "control").map((r) => <option key={r.id} value={r.id}>{r.label}</option>)}
            </select>
          </Field>
          {err && <p role="alert" className="text-sm font-bold text-destructive sm:col-span-2 lg:col-span-4">{err}</p>}
          <div className="sm:col-span-2 lg:col-span-4"><Button type="submit">إنشاء الحساب</Button></div>
        </form>
      </Panel>

      <Panel title="حسابات الجهات" icon={<ShieldCheck className="size-5" />}>
        <Table head={["الاسم", "المستخدم", "الدور", "الحالة", "إجراءات"]}>
          {accounts.map((a) => (
            <tr key={a.id}>
              <td className="font-bold">{a.name}</td>
              <td dir="ltr" className="text-right text-muted-foreground">{a.username}</td>
              <td>{roleLabel(a.role)}</td>
              <td>
                {a.role === "control" ? <span className="rounded-full bg-primary-soft px-2.5 py-0.5 text-xs font-bold text-primary-deep">مفعّل</span> : (
                  <button type="button" onClick={() => setAccounts((x) => x.map((y) => y.id === a.id ? { ...y, active: !y.active } : y))}
                    className={`rounded-full px-2.5 py-0.5 text-xs font-bold ${a.active ? "bg-primary-soft text-primary-deep" : "bg-muted text-muted-foreground"}`}>
                    {a.active ? "مفعّل" : "موقوف"}
                  </button>
                )}
              </td>
              <td><Button size="sm" variant="outline" onClick={() => { setPwFor(pwFor === a.id ? null : a.id); setNewPw(""); }}><KeyRound />كلمة المرور</Button></td>
            </tr>
          ))}
        </Table>

        {pwFor !== null && (
          <form className="mt-4 grid gap-3 rounded-md border border-primary/30 bg-primary-soft/40 p-4 sm:grid-cols-3"
            onSubmit={(e) => {
              e.preventDefault();
              setAccounts((x) => x.map((y) => y.id === pwFor ? { ...y, password: newPw } : y));
              toast.success("تم تغيير كلمة المرور"); setPwFor(null);
            }}>
            <Field label="كلمة المرور الجديدة"><input className={inputCls} dir="ltr" required minLength={4} value={newPw} onChange={(e) => setNewPw(e.target.value)} /></Field>
            <div className="flex items-end"><Button type="submit">حفظ</Button></div>
          </form>
        )}
      </Panel>
    </div>
  );
}
