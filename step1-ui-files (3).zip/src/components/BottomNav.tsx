import { FileText, HandHeart, Home, Mail, ShieldCheck, TrendingUp, Users } from "lucide-react";

/** شريط التبويبات السفلي — نفس تصميم الموقع، مع تبويبة «الإدارة». التبويب النشط يأتي من الصفحة. */
const items = [
  { id: "home", href: "#home", label: "الرئيسية", icon: Home },
  { id: "about", href: "#about", label: "قصتنا", icon: Users },
  { id: "impact", href: "#impact", label: "أثرنا", icon: TrendingUp },
  { id: "donate", href: "#donate", label: "التبرع", icon: HandHeart },
  { id: "reports", href: "#reports", label: "التقارير", icon: FileText },
  { id: "contact", href: "#contact", label: "تواصل", icon: Mail },
  { id: "admin", href: "/admin", label: "الإدارة", icon: ShieldCheck },
] as const;

export function BottomNav({ active }: { active: string }) {
  return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      aria-label="التنقل السريع"
      className="fixed inset-x-0 bottom-0 z-50 border-t border-border bg-background/95 backdrop-blur-xl"
      style={{ paddingBottom: "env(safe-area-inset-bottom, 0px)" }}
    >
      <ul className="mx-auto flex max-w-2xl items-stretch gap-0.5 px-1.5 py-1.5">
        {items.map((it) => {
          const on = active === it.id;
          return (
            <li key={it.id} className="flex-1">
              <a
                href={it.href}
                aria-current={on ? "page" : undefined}
                className={`flex flex-col items-center gap-1 rounded-xl px-1 py-2 text-[11px] font-bold transition-colors ${
                  on ? "bg-primary-soft text-primary-deep" : "text-muted-foreground hover:text-primary"
                }`}
              >
                <it.icon className="size-5" />
                {it.label}
              </a>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
