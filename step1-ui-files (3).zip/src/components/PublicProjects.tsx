import { useState } from "react";
import { GraduationCap, Hammer, ExternalLink, Hourglass } from "lucide-react";
import { Button } from "@/components/ui/button";
import { plans, trainings, fmt } from "@/lib/mock-admin";

// بيانات تجريبية — ستُقرأ لاحقاً من Supabase (قراءة عامة فقط عبر RLS)
const tabs = [
  { id: "running", label: "قيد التنفيذ", icon: Hammer },
  { id: "plan", label: "الخطط القادمة", icon: Hourglass },
  { id: "training", label: "فرص التدريب", icon: GraduationCap },
] as const;

export function PublicProjects() {
  const [tab, setTab] = useState<(typeof tabs)[number]["id"]>("running");
  const items = plans.filter((p) => p.kind === tab);

  return (
    <section id="projects" className="relative overflow-hidden py-24">
      <div className="relative mx-auto max-w-5xl px-4 sm:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <span className="inline-flex items-center gap-2 rounded-full bg-primary-soft px-4 py-2 text-sm font-bold text-primary-deep">
            <Hammer className="size-4" /> مشاريعنا
          </span>
          <h2 className="mt-5 text-3xl font-black sm:text-5xl">مشاريع وفرص تنمو بكم</h2>
          <p className="mx-auto mt-4 max-w-xl leading-loose text-muted-foreground">
            تعرّف على ما نعمل عليه الآن، وما نخطط له، وفرص التدريب والتأهيل للأسر.
          </p>
        </div>

        <div role="tablist" className="mx-auto mt-10 flex max-w-lg gap-2 rounded-md border border-border bg-card p-1.5 shadow-soft">
          {tabs.map((t) => (
            <button key={t.id} role="tab" aria-selected={tab === t.id} type="button" onClick={() => setTab(t.id)}
              className={`flex flex-1 items-center justify-center gap-1.5 rounded-md px-2 py-2.5 text-xs font-bold transition sm:text-sm ${tab === t.id ? "bg-primary text-primary-foreground shadow-soft" : "text-muted-foreground hover:text-primary"}`}>
              <t.icon className="size-4" />{t.label}
            </button>
          ))}
        </div>

        <div className="mt-8 grid gap-4 sm:grid-cols-2">
          {tab !== "training" && items.map((p) => (
            <article key={p.id} className="rounded-md border border-border bg-card p-6 shadow-soft transition hover:-translate-y-1 hover:shadow-lift">
              <h3 className="text-xl font-black text-primary-deep">{p.title}</h3>
              <p className="mt-2 leading-loose text-muted-foreground">{p.desc}</p>
              <p className="mt-4 inline-flex rounded-full bg-accent-soft px-3 py-1 text-sm font-bold text-accent">المطلوب: {fmt(p.target)} ج.س</p>
            </article>
          ))}
          {tab === "training" && trainings.map((t) => (
            <article key={t.id} className="rounded-md border border-border bg-card p-6 shadow-soft transition hover:-translate-y-1 hover:shadow-lift">
              <h3 className="text-xl font-black text-primary-deep">{t.title}</h3>
              <p className="mt-1 text-sm font-bold text-accent">الفئة: {t.audience}</p>
              <p className="mt-2 leading-loose text-muted-foreground">{t.details}</p>
              <Button asChild variant="gold" size="sm" className="mt-4">
                <a href={t.link} target="_blank" rel="noreferrer"><ExternalLink />قدّم الآن</a>
              </Button>
            </article>
          ))}
          {tab !== "training" && items.length === 0 && (
            <p className="col-span-full py-8 text-center text-muted-foreground">لا توجد عناصر حالياً.</p>
          )}
        </div>
      </div>
    </section>
  );
}
