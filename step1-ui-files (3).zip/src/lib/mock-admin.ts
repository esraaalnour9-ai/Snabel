// ===== بيانات تجريبية (Mock Data) للمرحلة الأولى: مراجعة الواجهات فقط =====
// لا يوجد اتصال بقاعدة البيانات هنا. في المرحلة الثانية تُستبدل بجداول Supabase + RLS.
import {
  BadgeCheck, Banknote, Clapperboard, Crown, GraduationCap, HandCoins,
  Hammer, Users, Wallet, type LucideIcon,
} from "lucide-react";

export type Role =
  | "control" | "membership" | "collector" | "finance"
  | "projects" | "auditor" | "media" | "training";

export const ROLES: { id: Role; label: string; hint: string; icon: LucideIcon }[] = [
  { id: "control", label: "الكنترول", hint: "المصمم / المدير العام", icon: Crown },
  { id: "membership", label: "شؤون العضوية", hint: "بيانات الأعضاء والتذكير", icon: Users },
  { id: "collector", label: "المتحصل", hint: "إشعارات الدفع والتحويل", icon: HandCoins },
  { id: "finance", label: "المالية", hint: "الاستلام والصرف والتقارير", icon: Wallet },
  { id: "projects", label: "المشاريع والتكية", hint: "المنصرفات والخطط", icon: Hammer },
  { id: "auditor", label: "المراجع المالي", hint: "مطابقة الإدارات", icon: BadgeCheck },
  { id: "media", label: "الإعلام", hint: "نشر الإنجازات", icon: Clapperboard },
  { id: "training", label: "إدارة التدريب", hint: "ورش ودورات الأسر", icon: GraduationCap },
];

export const roleLabel = (r: Role) => ROLES.find((x) => x.id === r)!.label;
export { Banknote };

// حساب الكنترول التجريبي الوحيد؛ باقي الحسابات ينشئها الكنترول من واجهته (في الذاكرة فقط).
// المرحلة الثانية: Supabase Auth — ولا تُخزَّن كلمات المرور في الكود أو في أي جدول.
export type Account = { id: number; name: string; username: string; password: string; role: Role; active: boolean; img?: string };
export const initialAccounts: Account[] = [
  { id: 1, name: "المدير العام", username: "control", password: "Control#123", role: "control", active: true },
];

export const MONTHLY_FEE = 10000;

export type Member = {
  id: number; name: string; phone: string; whatsapp: string; joined: string; notes: string;
};
export const members: Member[] = [
  { id: 1, name: "أحمد محمد الطيب", phone: "0911000001", whatsapp: "0911000001", joined: "2026-08-01", notes: "عضو مؤسس" },
  { id: 2, name: "فاطمة عبدالله", phone: "0912000002", whatsapp: "0912000002", joined: "2026-08-03", notes: "" },
  { id: 3, name: "محمود إبراهيم", phone: "0923000003", whatsapp: "0923000003", joined: "2026-08-05", notes: "يدفع عبر التطبيق" },
  { id: 4, name: "إسراء النور", phone: "0911000004", whatsapp: "0911000004", joined: "2026-08-07", notes: "" },
  { id: 5, name: "عثمان الفضيل", phone: "0915000005", whatsapp: "0915000005", joined: "2026-09-02", notes: "" },
  { id: 6, name: "مريم حسن", phone: "0916000006", whatsapp: "0916000006", joined: "2026-09-04", notes: "" },
  { id: 7, name: "يوسف آدم", phone: "0917000007", whatsapp: "0917000007", joined: "2026-09-09", notes: "" },
  { id: 8, name: "سارة بشير", phone: "0918000008", whatsapp: "0918000008", joined: "2026-10-01", notes: "عضو جديد" },
];
// أعضاء سدّدوا هذا الشهر (تجريبي)
export const paidThisMonth = new Set([1, 2, 4, 5, 8]);

// حالة الإشعار: مسجَّل (في عهدة المتحصل) ← مُرسل للمالية ← مؤكَّد استلامه
export type PayStatus = "recorded" | "sent" | "confirmed";
export type PaymentNotice = {
  id: number; memberId: number; // 0 = غير مسجَّل في شؤون العضوية (يُستخدم payer/phone)
  payer?: string; phone?: string;
  date: string; ref: string;
  sub: number; con: number; // اشتراك + مساهمة في إشعار واحد (أيٌّ منهما قد يكون 0)
  amount: number; // الإجمالي = sub + con
  desc: string; // وصف المساهمة
  months: number; // عدد أشهر الاشتراك المدفوعة (0 إن لم يوجد اشتراك) — أكثر من 1 = دفع مقدَّم
  status: PayStatus;
};
export const payments: PaymentNotice[] = [
  { id: 1, memberId: 1, date: "2026-11-02", ref: "TX-10231", sub: 10000, con: 0, amount: 10000, desc: "", months: 1, status: "confirmed" },
  { id: 2, memberId: 2, date: "2026-11-03", ref: "TX-10244", sub: 10000, con: 0, amount: 10000, desc: "", months: 1, status: "confirmed" },
  { id: 3, memberId: 4, date: "2026-11-04", ref: "TX-10260", sub: 10000, con: 0, amount: 10000, desc: "", months: 1, status: "confirmed" },
  { id: 4, memberId: 4, date: "2026-11-04", ref: "TX-10261", sub: 0, con: 20000, amount: 20000, desc: "صدقة لروح الوالد", months: 0, status: "confirmed" },
  { id: 5, memberId: 5, date: "2026-11-06", ref: "TX-10302", sub: 10000, con: 0, amount: 10000, desc: "", months: 1, status: "sent" },
  { id: 6, memberId: 8, date: "2026-11-08", ref: "TX-10355", sub: 10000, con: 0, amount: 10000, desc: "", months: 1, status: "sent" },
];

export type Transfer = { id: number; collector: string; date: string; amount: number; ref: string; confirmed: boolean; paymentIds: number[]; partnerIds: number[] };
export const transfers: Transfer[] = [
  { id: 1, collector: "المتحصل: خالد", date: "2026-11-05", amount: 50000, ref: "TR-501", confirmed: true, paymentIds: [1, 2, 3, 4], partnerIds: [] },
  { id: 2, collector: "المتحصل: خالد", date: "2026-11-09", amount: 20000, ref: "TR-518", confirmed: false, paymentIds: [5, 6], partnerIds: [] },
];

// ===== الخزن الثلاث في المالية — كل مبلغ يُرحَّل تلقائياً إلى الخزنة التي تحمل اسمه =====
export type Treasury = "subs" | "cons" | "ext";
export const TREASURIES: { id: Treasury; label: string }[] = [
  { id: "subs", label: "خزنة الاشتراكات الشهرية" },
  { id: "cons", label: "خزنة مساهمات الأعضاء" },
  { id: "ext", label: "خزنة الشراكات الخارجية" },
];

// دعم/شراكة خارجية: يسجّلها المتحصل (تمر بالعهدة والتحويل) أو المالية مباشرة (تُؤكَّد فوراً)
export type Partnership = { id: number; party: string; type: string; amount: number; ref: string; date: string; status: PayStatus; source: "collector" | "finance" };
export const partnerships: Partnership[] = [
  { id: 1, party: "قروب قروة الخير", type: "شراكة", amount: 50000, ref: "PT-77", date: "2026-11-07", status: "confirmed", source: "finance" },
  { id: 2, party: "دعم التكية - فاعل خير", type: "دعم مباشر", amount: 25000, ref: "PT-81", date: "2026-11-10", status: "confirmed", source: "finance" },
];

export type Outflow = { id: number; treasurer: string; treasury: Treasury; recipient: string; amount: number; date: string; ref: string };
export const outflows: Outflow[] = [
  { id: 1, treasurer: "الأمين المالي: عمر", treasury: "subs", recipient: "إدارة المشاريع", amount: 20000, date: "2026-11-10", ref: "OUT-301" },
  { id: 2, treasurer: "الأمين المالي: عمر", treasury: "cons", recipient: "التكية", amount: 10000, date: "2026-11-10", ref: "OUT-302" },
  { id: 3, treasurer: "الأمين المالي: عمر", treasury: "ext", recipient: "التكية", amount: 30000, date: "2026-11-10", ref: "OUT-303" },
];

/** أرصدة الخزن من الحركات المؤكَّدة فقط (الوارد يُرحَّل تلقائياً عند تأكيد الاستلام) */
export function computeTreasuries(pays: PaymentNotice[], parts: Partnership[], outs: Outflow[]) {
  const sum = <T,>(xs: T[], f: (x: T) => number) => xs.reduce((s, x) => s + f(x), 0);
  const conf = pays.filter((p) => p.status === "confirmed");
  const inn: Record<Treasury, number> = {
    subs: sum(conf, (p) => p.sub), cons: sum(conf, (p) => p.con), ext: sum(parts.filter((x) => x.status === "confirmed"), (x) => x.amount),
  };
  return TREASURIES.map((t) => {
    const out = sum(outs.filter((o) => o.treasury === t.id), (o) => o.amount);
    return { ...t, in: inn[t.id], out, balance: inn[t.id] - out };
  });
}

export type Project = {
  id: number; name: string; date: string; status: "active" | "done";
  expenses: { id: number; item: string; qty: number; unit: number }[];
};
export const projects: Project[] = [
  {
    id: 1, name: "التكية الشهرية", date: "2026-11-10", status: "active",
    expenses: [
      { id: 1, item: "دقيق (كجم)", qty: 60, unit: 600 },
      { id: 2, item: "عدس (كجم)", qty: 20, unit: 1200 },
      { id: 3, item: "زيت (لتر)", qty: 10, unit: 1500 },
    ],
  },
  {
    id: 2, name: "دعم أسرة - صينية إفطار", date: "2026-10-14", status: "done",
    expenses: [
      { id: 1, item: "وجبات", qty: 21, unit: 1000 },
      { id: 2, item: "نقل", qty: 1, unit: 5000 },
    ],
  },
];

export type Plan = { id: number; title: string; desc: string; target: number; kind: "plan" | "running" };
export const plans: Plan[] = [
  { id: 1, title: "تكية الطلاب", desc: "وجبة غداء أسبوعية لطلاب المدارس المحتاجين في الحي.", target: 150000, kind: "plan" },
  { id: 2, title: "إفطار الطلاب", desc: "إفطار جماعي للطلاب في الجامعات والمعاهد خلال الشهر الكريم.", target: 200000, kind: "plan" },
  { id: 3, title: "سلة الدقيق والعدس", desc: "توزيع ٢١ سلة على الأسر المتعففة هذا الشهر.", target: 210000, kind: "running" },
];

export type Post = { id: number; title: string; body: string; date: string; media: "none" | "image" | "video" };
export const posts: Post[] = [
  { id: 1, title: "توزيع سلال أكتوبر", body: "تم دعم ٢١ أسرة بدقيق ومكرونة.", date: "2026-10-14", media: "image" },
  { id: 2, title: "ختام التكية", body: "شكراً لكل من ساهم وشارك.", date: "2026-10-20", media: "video" },
];

export type Training = { id: number; title: string; audience: string; details: string; link: string };
export const trainings: Training[] = [
  { id: 1, title: "ورشة الخياطة وصناعة الملابس", audience: "ربات الأسر", details: "ثمانية أسابيع، مع توفير الماكينات.", link: "https://forms.gle/example1" },
  { id: 2, title: "دورة الحاسوب الأساسية", audience: "الشباب من الأسر المتعففة", details: "مهارات مكتبية للبحث عن عمل.", link: "https://forms.gle/example2" },
];

export const total = (xs: { qty: number; unit: number }[]) => xs.reduce((s, x) => s + x.qty * x.unit, 0);
export const fmt = (n: number) => n.toLocaleString("en-US");

// ===== رسائل التذكير التحفيزية الافتراضية (يعدّلها أمين شؤون العضوية من الإعدادات) =====
export const DEFAULT_MESSAGES = [
  "السلام عليكم ورحمة الله يا {الاسم} 🌾 اقترب موعد المساهمة الشهرية ({المبلغ})، وبمساهمتك تصل سلة إلى أسرة تنتظر الخير. جزاك الله خيراً.",
  "السلام عليكم {الاسم}، فُتح اليوم باب المساهمة الشهرية ({المبلغ}). كل سنبلة تبدأ بحبة، فكن سبب سنبلة جديدة 🌾",
  "السلام عليكم {الاسم}، تذكير لطيف بمساهمتك الشهرية ({المبلغ}). أسر كثيرة بانتظار سلالنا، وجزاك الله خير الجزاء.",
  "السلام عليكم {الاسم}، اليوم آخر موعد للمساهمة الشهرية ({المبلغ}). شاركنا قبل أن يُغلق الباب، وبارك الله فيك.",
];

// ===== بيانات التقارير التجريبية (العمود الأول دائماً تاريخ YYYY-MM-DD) =====
export type StatItem = { label: string; value: string | number; tone?: "primary" | "gold" | "danger" };
export type ReportDef = { title: string; cols: string[]; rows: (string | number)[][]; summary: (rows: (string | number)[][]) => StatItem[] };
const sumCol = (rows: (string | number)[][], i: number) => rows.reduce((s, r) => s + Number(r[i]), 0);

export const reportData: Record<Role, ReportDef> = {
  control: {
    title: "التقرير الشامل", cols: ["الشهر", "أعضاء جدد", "المحصَّل", "الصرف"],
    rows: [["2026-08-31", 4, 0, 0], ["2026-09-30", 3, 35000, 30000], ["2026-10-31", 1, 30000, 45000], ["2026-11-30", 0, 110000, 60000]],
    summary: (r) => [{ label: "أعضاء جدد", value: sumCol(r, 1) }, { label: "المحصَّل", value: fmt(sumCol(r, 2)) }, { label: "الصرف", value: fmt(sumCol(r, 3)), tone: "danger" }],
  },
  membership: {
    title: "تقرير العضوية", cols: ["تاريخ الانضمام", "العضو", "الهاتف"],
    rows: members.map((m) => [m.joined, m.name, m.phone]),
    summary: (r) => [{ label: "منضمون جدد", value: r.length }],
  },
  collector: {
    title: "تقرير التحصيل", cols: ["التاريخ", "العضو", "العملية", "المبلغ", "النوع"],
    rows: [
      ["2026-09-03", "أحمد محمد الطيب", "TX-9001", 10000, "اشتراك"], ["2026-09-05", "فاطمة عبدالله", "TX-9014", 10000, "اشتراك"],
      ["2026-09-07", "إسراء النور", "TX-9022", 15000, "مساهمة — صدقة"], ["2026-10-02", "أحمد محمد الطيب", "TX-9801", 10000, "اشتراك"],
      ["2026-10-04", "محمود إبراهيم", "TX-9815", 10000, "اشتراك"], ["2026-10-06", "فاطمة عبدالله", "TX-9833", 10000, "اشتراك"],
      ["2026-11-02", "أحمد محمد الطيب", "TX-10231", 10000, "اشتراك"], ["2026-11-03", "فاطمة عبدالله", "TX-10244", 10000, "اشتراك"],
      ["2026-11-04", "إسراء النور", "TX-10261", 20000, "مساهمة — صدقة لروح الوالد"], ["2026-11-06", "عثمان الفضيل", "TX-10302", 10000, "اشتراك"],
    ],
    summary: (r) => [
      { label: "إجمالي التحصيل", value: fmt(sumCol(r, 3)) },
      { label: "اشتراكات", value: fmt(sumCol(r.filter((x) => x[4] === "اشتراك"), 3)) },
      { label: "مساهمات", value: fmt(sumCol(r.filter((x) => x[4] !== "اشتراك"), 3)), tone: "gold" },
    ],
  },
  finance: {
    title: "التقرير المالي", cols: ["التاريخ", "الحركة", "الجهة", "المبلغ"],
    rows: [
      ["2026-09-08", "استلام من المتحصل", "خالد", 35000], ["2026-09-12", "صرف", "إدارة المشاريع", 30000],
      ["2026-10-09", "استلام من المتحصل", "خالد", 30000], ["2026-10-10", "دعم خارجي", "قروب قروة الخير", 50000], ["2026-10-12", "صرف", "التكية", 45000],
      ["2026-11-05", "استلام من المتحصل", "خالد", 40000], ["2026-11-07", "دعم خارجي", "قروب قروة الخير", 50000], ["2026-11-10", "صرف", "إدارة المشاريع - التكية", 60000],
    ],
    summary: (r) => {
      const inn = sumCol(r.filter((x) => x[1] !== "صرف"), 3), out = sumCol(r.filter((x) => x[1] === "صرف"), 3);
      return [{ label: "الوارد", value: fmt(inn) }, { label: "الصرف", value: fmt(out), tone: "danger" }, { label: "الصافي", value: fmt(inn - out), tone: "gold" }];
    },
  },
  projects: {
    title: "تقرير المشاريع والتكية", cols: ["التاريخ", "المشروع", "المنصرف", "الإجمالي"],
    rows: [
      ["2026-09-12", "سلال سبتمبر", "دقيق وعدس", 90000], ["2026-10-14", "دعم أسرة - صينية إفطار", "وجبات", 21000], ["2026-10-14", "دعم أسرة - صينية إفطار", "نقل", 5000],
      ["2026-11-10", "التكية الشهرية", "دقيق", 36000], ["2026-11-10", "التكية الشهرية", "عدس", 24000], ["2026-11-10", "التكية الشهرية", "زيت", 15000],
    ],
    summary: (r) => [{ label: "إجمالي المنصرفات", value: fmt(sumCol(r, 3)), tone: "danger" }, { label: "عدد البنود", value: r.length }],
  },
  auditor: {
    title: "تقرير المراجعة", cols: ["الشهر", "المحصَّل", "المرسل للمالية", "الفرق"],
    rows: [["2026-09-30", 35000, 35000, 0], ["2026-10-31", 30000, 30000, 0], ["2026-11-30", 110000, 70000, 40000]],
    summary: (r) => [
      { label: "أشهر متطابقة", value: r.filter((x) => Number(x[3]) === 0).length },
      { label: "أشهر بها فرق", value: r.filter((x) => Number(x[3]) !== 0).length, tone: "danger" },
      { label: "إجمالي الفروق", value: fmt(sumCol(r, 3)), tone: "gold" },
    ],
  },
  media: {
    title: "تقرير الإعلام", cols: ["التاريخ", "العنوان", "المرفق"],
    rows: [["2026-09-12", "توزيع سلال سبتمبر", "صورة"], ["2026-10-14", "توزيع سلال أكتوبر", "صورة"], ["2026-10-20", "ختام التكية", "فيديو"]],
    summary: (r) => [{ label: "منشورات", value: r.length }],
  },
  training: {
    title: "تقرير التدريب", cols: ["التاريخ", "الفرصة", "الفئة"],
    rows: [["2026-09-20", "ورشة الخياطة وصناعة الملابس", "ربات الأسر"], ["2026-10-25", "دورة الحاسوب الأساسية", "الشباب"]],
    summary: (r) => [{ label: "فرص منشورة", value: r.length }],
  },
};

// ===== إعدادات خاصة بكل إدارة (تُعدَّل من تبويبة «الإعدادات» عند صاحب الإدارة) =====
export type AppSettings = {
  fee: number; // الكنترول: قيمة الاشتراك الشهري
  collectorName: string; collectorMsg: string; // المتحصل: اسمه + رسالة الواتساب الافتراضية
  treasurerName: string; recipients: string[]; // المالية: اسم الأمين + الجهات المستلمة
  items: string[]; // المشاريع: بنود المنصرفات الشائعة
  tolerance: number; // المراجع: الفرق المقبول بين الإدارات
  mediaFooter: string; // الإعلام: خاتمة ثابتة للمنشورات
  trainingLink: string; // التدريب: رابط الاستمارة الافتراضي
};
export const DEFAULT_SETTINGS: AppSettings = {
  fee: MONTHLY_FEE,
  collectorName: "المتحصل: خالد",
  collectorMsg: "السلام عليكم {الاسم}، استلمنا {التفاصيل} بمبلغ {المبلغ} ج.س بتاريخ {التاريخ} — رقم العملية {رقم العملية}. جزاك الله خيراً 🌾 سنابل الخير",
  treasurerName: "الأمين المالي: عمر",
  recipients: ["إدارة المشاريع", "التكية", "الحوجات"],
  items: ["دقيق (كجم)", "عدس (كجم)", "زيت (لتر)", "مكرونة (كجم)", "نقل"],
  tolerance: 0,
  mediaFooter: "سنابل الخير — عطاء ينمو وأثر يبقى 🌾",
  trainingLink: "https://forms.gle/example",
};

/** يستبدل المتغيرات مثل {الاسم} في نص الرسالة */
export const fillTemplate = (tpl: string, vars: Record<string, string>) =>
  Object.entries(vars).reduce((t, [k, v]) => t.split(`{${k}}`).join(v), tpl);
